/** @type {import('next').NextConfig} */
const nextConfig = {
  // Phase 2: static export removed. NextAuth + Prisma + /api/* require a
  // real Node runtime (Vercel/Railway/Render/etc). Deploy with `next start`
  // — never `output: 'export'` for this project.
  trailingSlash: false,
  reactStrictMode: true,
  images: {
    unoptimized: true,
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      { protocol: 'https', hostname: '**' },
    ],
  },
  experimental: {
    serverActions: {
      bodySizeLimit: '8mb',
    },
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
};

export default nextConfig;
