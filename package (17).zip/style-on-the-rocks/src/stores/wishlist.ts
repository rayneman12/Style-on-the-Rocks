'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type WishlistState = {
  productIds: string[];
  has: (id: string) => boolean;
  toggle: (id: string) => void;
  clear: () => void;
};

export const useWishlist = create<WishlistState>()(
  persist(
    (set, get) => ({
      productIds: [],
      has: (id) => get().productIds.includes(id),
      toggle: (id) => {
        const has = get().productIds.includes(id);
        set({
          productIds: has
            ? get().productIds.filter((x) => x !== id)
            : [...get().productIds, id],
        });
      },
      clear: () => set({ productIds: [] }),
    }),
    { name: 'sotr-wishlist' },
  ),
);