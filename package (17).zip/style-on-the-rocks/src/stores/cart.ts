'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type CartLine = {
  productId: string;
  productSlug: string;
  productName: string;
  size: string;
  color?: string | null;
  unitPriceCents: number;
  quantity: number;
  image?: string;
};

type CartState = {
  lines: CartLine[];
  add: (line: CartLine) => void;
  update: (productId: string, size: string, quantity: number) => void;
  remove: (productId: string, size: string) => void;
  clear: () => void;
  count: () => number;
  subtotalCents: () => number;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      add: (line) => {
        const lines = get().lines.slice();
        const i = lines.findIndex(
          (l) => l.productId === line.productId && l.size === line.size,
        );
        if (i >= 0) {
          lines[i] = { ...lines[i], quantity: lines[i].quantity + line.quantity };
        } else {
          lines.push(line);
        }
        set({ lines });
      },
      update: (productId, size, quantity) => {
        const lines = get()
          .lines.map((l) =>
            l.productId === productId && l.size === size ? { ...l, quantity } : l,
          )
          .filter((l) => l.quantity > 0);
        set({ lines });
      },
      remove: (productId, size) => {
        set({
          lines: get().lines.filter(
            (l) => !(l.productId === productId && l.size === size),
          ),
        });
      },
      clear: () => set({ lines: [] }),
      count: () => get().lines.reduce((a, l) => a + l.quantity, 0),
      subtotalCents: () => get().lines.reduce((a, l) => a + l.unitPriceCents * l.quantity, 0),
    }),
    { name: 'sotr-cart' },
  ),
);