'use client';
import Link from 'next/link';
import { useUI } from '@/stores/ui';
import { useCart } from '@/stores/cart';
import { formatZAR } from '@/lib/pricing';
import Image from 'next/image';

export function CartDrawer() {
  const open = useUI((s) => s.cartOpen);
  const close = useUI((s) => s.closeCart);
  const lines = useCart((s) => s.lines);
  const update = useCart((s) => s.update);
  const remove = useCart((s) => s.remove);
  const subtotal = useCart((s) => s.lines.reduce((a, l) => a + l.unitPriceCents * l.quantity, 0));

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Cart">
      <button
        aria-label="Close cart"
        onClick={close}
        className="absolute inset-0 bg-ink/40"
      />
      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md flex-col bg-ivory-50 shadow-soft">
        <header className="flex items-center justify-between border-b border-ink-200 px-5 py-4">
          <p className="eyebrow">Your bag</p>
          <button onClick={close} aria-label="Close cart" className="text-sm uppercase tracking-wider2">Close</button>
        </header>
        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-5 text-center">
            <p className="font-serif text-2xl">Your bag is empty</p>
            <Link href="/shop/women" onClick={close} className="btn-secondary">Continue shopping</Link>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-ink-200 overflow-y-auto px-5">
              {lines.map((l) => (
                <li key={`${l.productId}-${l.size}`} className="flex gap-3 py-4">
                  <div className="h-20 w-16 flex-none overflow-hidden bg-ivory-200">
                    {l.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={l.image} alt="" className="h-full w-full object-cover" />
                    ) : null}
                  </div>
                  <div className="flex-1 text-sm">
                    <Link href={`/product/${l.productSlug}`} onClick={close} className="font-serif text-base">
                      {l.productName}
                    </Link>
                    <p className="text-ink-500">Size {l.size}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <button onClick={() => update(l.productId, l.size, l.quantity - 1)} aria-label="Decrease quantity" className="h-7 w-7 border border-ink-200">−</button>
                      <span className="w-6 text-center">{l.quantity}</span>
                      <button onClick={() => update(l.productId, l.size, l.quantity + 1)} aria-label="Increase quantity" className="h-7 w-7 border border-ink-200">+</button>
                      <button onClick={() => remove(l.productId, l.size)} className="ml-3 text-xs uppercase tracking-wider2 text-ink-500 underline-offset-4 hover:underline">Remove</button>
                    </div>
                  </div>
                  <div className="text-sm">{formatZAR(l.unitPriceCents * l.quantity)}</div>
                </li>
              ))}
            </ul>
            <footer className="border-t border-ink-200 p-5">
              <div className="mb-3 flex items-center justify-between text-sm">
                <span>Subtotal</span>
                <span className="font-serif text-lg">{formatZAR(subtotal)}</span>
              </div>
              <Link href="/cart" onClick={close} className="btn-secondary mb-2 w-full">View bag</Link>
              <Link href="/checkout" onClick={close} className="btn-primary w-full">Checkout</Link>
              <p className="mt-3 text-xs text-ink-500">VAT-inclusive. Shipping calculated at checkout.</p>
            </footer>
          </>
        )}
      </aside>
    </div>
  );
}