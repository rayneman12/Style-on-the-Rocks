'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useUI } from '@/stores/ui';
import { useCart } from '@/stores/cart';
import { SearchBar } from './search-bar';

const NAV = [
  { href: '/shop/women', label: 'Women' },
  { href: '/shop/men', label: 'Men' },
  { href: '/new-arrivals', label: 'New' },
  { href: '/sale', label: 'Sale' },
  { href: '/journal', label: 'Journal' },
  { href: '/visit-us', label: 'Visit us' },
];

export function SiteHeader() {
  const openCart = useUI((s) => s.openCart);
  const cartCount = useCart((s) => s.lines.reduce((a, l) => a + l.quantity, 0));
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  return (
    <header className="sticky top-0 z-40 border-b border-ink-200 bg-ivory-50/95 backdrop-blur">
      <div className="container-x flex items-center gap-6 py-3 md:py-4">
        <Link href="/" className="font-serif text-2xl tracking-wide md:text-3xl">
          Style on the Rocks
        </Link>
        <nav className="hidden flex-1 items-center justify-center gap-8 md:flex" aria-label="Primary">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className="text-sm uppercase tracking-wider2 hover:text-ocean">
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-3 md:gap-5">
          <SearchBar />
          <Link href="/wishlist" className="hidden md:inline text-sm uppercase tracking-wider2 hover:text-ocean" aria-label="Wishlist">
            Wishlist
          </Link>
          <Link href="/account" className="hidden md:inline text-sm uppercase tracking-wider2 hover:text-ocean" aria-label="Account">
            Account
          </Link>
          <button onClick={openCart} className="relative text-sm uppercase tracking-wider2 hover:text-ocean" aria-label="Open cart">
            Cart
            {hydrated && cartCount > 0 ? (
              <span className="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-ink px-1.5 text-xs text-ivory-50">{cartCount}</span>
            ) : null}
          </button>
        </div>
      </div>
    </header>
  );
}