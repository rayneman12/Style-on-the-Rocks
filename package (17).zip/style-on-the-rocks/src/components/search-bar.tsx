'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useUI } from '@/stores/ui';

export function SearchBar() {
  const [q, setQ] = useState('');
  const router = useRouter();
  const toggleSearch = useUI((s) => s.toggleSearch);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (!term) return;
    router.push(`/search?q=${encodeURIComponent(term)}`);
  };
  return (
    <form onSubmit={submit} className="hidden items-center md:flex">
      <label className="sr-only" htmlFor="header-search">Search</label>
      <input
        id="header-search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search"
        className="w-32 border-b border-transparent bg-transparent py-1 text-sm placeholder-ink-400 focus:w-56 focus:border-ocean focus:outline-none"
      />
    </form>
  );
}