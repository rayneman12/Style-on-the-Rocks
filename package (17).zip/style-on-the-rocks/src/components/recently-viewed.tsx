'use client';
import { useEffect, useState } from 'react';
import { ProductCard } from './product-card';

export function RecentlyViewed({ currentSlug }: { currentSlug: string }) {
  const [products, setProducts] = useState<any[]>([]);
  useEffect(() => {
    try {
      const KEY = 'sotr-recent';
      const arr = (JSON.parse(localStorage.getItem(KEY) ?? '[]') as string[]).filter((s) => s !== currentSlug).slice(0, 4);
      if (!arr.length) return;
      fetch(`/api/recently-viewed?slugs=${encodeURIComponent(arr.join(','))}`)
        .then((r) => r.json())
        .then((data) => Array.isArray(data) ? setProducts(data) : null)
        .catch(() => null);
    } catch {}
  }, [currentSlug]);
  if (!products.length) return null;
  return (
    <section className="container-x pb-16">
      <h2 className="h-section mb-6">Recently viewed</h2>
      <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}