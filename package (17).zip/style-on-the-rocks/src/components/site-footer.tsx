import Link from 'next/link';
import { siteConfig, whatsappEnabled } from '@config/site.config';

export function SiteFooter() {
  const wa = whatsappEnabled();
  const year = new Date().getFullYear();
  const reg = siteConfig.legal.companyRegNumber;
  const vat = siteConfig.legal.vatNumber;
  const addr = [
    siteConfig.location.addressLine1,
    siteConfig.location.suburb,
    siteConfig.location.city,
    siteConfig.location.postcode,
  ].filter(Boolean);

  return (
    <footer className="mt-24 border-t border-ink-200 bg-ivory-100">
      <div className="container-x grid gap-10 py-14 md:grid-cols-4">
        <div>
          <p className="font-serif text-2xl">{siteConfig.brand.name}</p>
          <p className="mt-2 max-w-prose text-sm text-ink-600">{siteConfig.brand.tagline}</p>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm">
            <a href={siteConfig.contact.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-ocean underline-offset-4 hover:underline" aria-label="Instagram">
              Instagram
            </a>
            <span aria-hidden>·</span>
            <a href={siteConfig.contact.facebook} target="_blank" rel="noopener noreferrer" className="hover:text-ocean underline-offset-4 hover:underline" aria-label="Facebook">
              Facebook
            </a>
            <span aria-hidden>·</span>
            <a href={siteConfig.contact.tiktok} target="_blank" rel="noopener noreferrer" className="hover:text-ocean underline-offset-4 hover:underline" aria-label="TikTok">
              TikTok
            </a>
            {wa ? (
              <>
                <span aria-hidden>·</span>
                <a
                  href={`https://wa.me/${siteConfig.contact.whatsapp}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-ocean underline-offset-4 hover:underline"
                  aria-label="WhatsApp"
                >
                  WhatsApp
                </a>
              </>
            ) : null}
          </div>
        </div>

        <div>
          <p className="eyebrow mb-3">Shop</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/shop/women">Women</Link></li>
            <li><Link href="/shop/men">Men</Link></li>
            <li><Link href="/new-arrivals">New arrivals</Link></li>
            <li><Link href="/sale">Sale</Link></li>
            <li><Link href="/brands">Brands</Link></li>
            <li><Link href="/gift-cards">Gift cards</Link></li>
          </ul>
        </div>

        <div>
          <p className="eyebrow mb-3">Help</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/contact">Contact</Link></li>
            <li><Link href="/visit-us">Visit us</Link></li>
            <li><Link href="/delivery">Delivery</Link></li>
            <li><Link href="/returns">Returns &amp; refunds</Link></li>
            <li><Link href="/size-guide">Size guide</Link></li>
            <li><Link href="/faq">FAQ</Link></li>
          </ul>
        </div>

        <div>
          <p className="eyebrow mb-3">About</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/about">About</Link></li>
            <li><Link href="/journal">Journal</Link></li>
            <li><Link href="/book-a-stylist">Book a stylist</Link></li>
            <li><Link href="/privacy">Privacy</Link></li>
            <li><Link href="/terms">Terms</Link></li>
            <li><Link href="/cookies">Cookies</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-ink-200">
        <div className="container-x flex flex-col gap-2 py-6 text-xs text-ink-500 md:flex-row md:items-center md:justify-between">
          <p>© {year} {siteConfig.brand.name}. All rights reserved.</p>
          <p>
            {siteConfig.location.boutique}
            {addr.length ? ` · ${addr.join(', ')}` : ''}
            {' · '}
            South Africa
            {reg ? ` · Reg ${reg}` : ''}
            {vat ? ` · VAT ${vat}` : ''}
          </p>
          <p className="text-ink-400">
            ECTA supplier details — populate in <code>config/site.config.ts</code>
          </p>
        </div>
      </div>
    </footer>
  );
}