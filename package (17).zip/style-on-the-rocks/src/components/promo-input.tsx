'use client';
import { useEffect, useState } from 'react';
import { useCart } from '@/stores/cart';
import { formatZAR } from '@/lib/pricing';

export function PromoInput() {
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [discountCents, setDiscountCents] = useState(0);
  const [applied, setApplied] = useState<string | null>(null);
  const subtotal = useCart((s) => s.lines.reduce((a, l) => a + l.unitPriceCents * l.quantity, 0));

  const apply = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    const res = await fetch('/api/promo/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: code.trim(), subtotalCents: subtotal }),
    });
    const data = await res.json();
    if (data.ok) {
      setDiscountCents(data.discountCents);
      setApplied(code.trim().toUpperCase());
      setMsg({ ok: true, text: `Applied — you save ${formatZAR(data.discountCents)}.` });
      // Stash in sessionStorage so checkout can pick it up
      sessionStorage.setItem('sotr-promo', JSON.stringify({ code: code.trim().toUpperCase(), discountCents: data.discountCents }));
    } else {
      setMsg({ ok: false, text: data.reason ?? 'Invalid code.' });
      sessionStorage.removeItem('sotr-promo');
    }
  };

  const remove = () => {
    setApplied(null);
    setDiscountCents(0);
    setCode('');
    sessionStorage.removeItem('sotr-promo');
    setMsg(null);
  };

  return (
    <form onSubmit={apply} className="mt-4">
      <label className="label" htmlFor="promo-code">Promo code</label>
      <div className="flex gap-2">
        <input id="promo-code" value={code} onChange={(e) => setCode(e.target.value)} placeholder="WELCOME10" className="input" />
        {applied ? (
          <button type="button" onClick={remove} className="btn-secondary">Remove</button>
        ) : (
          <button type="submit" className="btn-secondary">Apply</button>
        )}
      </div>
      {msg ? (
        <p className={`mt-2 text-xs ${msg.ok ? 'text-ocean' : 'text-red-700'}`}>{msg.text}</p>
      ) : null}
      {applied ? (
        <p className="mt-2 text-xs text-ink-500">Promo <strong>{applied}</strong> applied — checkout will use {formatZAR(discountCents)} off.</p>
      ) : null}
    </form>
  );
}