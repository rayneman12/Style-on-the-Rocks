'use client';
import { useState } from 'react';

export function SizeGuide({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/40 p-4" role="dialog" aria-modal="true" aria-label="Size guide">
      <div className="w-full max-w-2xl bg-ivory-50 p-6 shadow-soft">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="h-card">Size guide</h2>
          <button onClick={onClose} className="text-sm uppercase tracking-wider2" aria-label="Close size guide">Close</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-200 text-left text-xs uppercase tracking-wider2">
                <th className="py-2">Size</th>
                <th className="py-2">Bust (cm)</th>
                <th className="py-2">Waist (cm)</th>
                <th className="py-2">Hips (cm)</th>
              </tr>
            </thead>
            <tbody>
              {[
                ['XS', 82, 64, 90],
                ['S', 86, 68, 94],
                ['M', 90, 72, 98],
                ['L', 94, 76, 102],
                ['XL', 98, 80, 106],
              ].map(([size, bust, waist, hips]) => (
                <tr key={size} className="border-b border-ink-200">
                  <td className="py-2 font-medium">{size}</td>
                  <td className="py-2">{bust}</td>
                  <td className="py-2">{waist}</td>
                  <td className="py-2">{hips}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="mt-3 text-xs text-ink-500">Measurements are body measurements, not garment. For footwear and accessories, see individual product pages.</p>
        </div>
      </div>
    </div>
  );
}