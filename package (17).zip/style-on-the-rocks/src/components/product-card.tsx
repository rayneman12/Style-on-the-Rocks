import Link from 'next/link';
import { formatZAR } from '@/lib/pricing';
import { stockState } from '@/lib/stock';

export type ProductCardData = {
  slug: string;
  name: string;
  priceCents: number;
  compareAtCents?: number | null;
  image?: string;
  isNew?: boolean;
  isOnSale?: boolean;
  minStock?: number;
};

export function ProductCard({ product }: { product: ProductCardData }) {
  const state = stockState(product.minStock ?? 0);
  return (
    <article className="group">
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden bg-ivory-200">
          {product.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={product.image}
              alt={product.name}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : null}
          {product.isNew ? (
            <span className="absolute left-3 top-3 bg-ivory-50 px-2 py-1 text-[10px] uppercase tracking-widest2">New</span>
          ) : null}
          {product.isOnSale ? (
            <span className="absolute right-3 top-3 bg-ocean px-2 py-1 text-[10px] uppercase tracking-widest2 text-ivory-50">Sale</span>
          ) : null}
        </div>
      </Link>
      <div className="mt-3 flex items-start justify-between gap-3">
        <div>
          <Link href={`/product/${product.slug}`} className="font-serif text-lg leading-snug hover:text-ocean">
            {product.name}
          </Link>
          {state === 'LOW_STOCK' ? <p className="text-xs text-brass">Low stock</p> : null}
          {state === 'SOLD_OUT' ? <p className="text-xs text-ink-500">Sold out</p> : null}
        </div>
        <div className="text-sm">
          {product.isOnSale && product.compareAtCents ? (
            <span className="mr-2 text-ink-400 line-through">{formatZAR(product.compareAtCents)}</span>
          ) : null}
          <span className="font-serif text-base">{formatZAR(product.priceCents)}</span>
        </div>
      </div>
    </article>
  );
}