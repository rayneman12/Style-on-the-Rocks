'use client';
import { useState } from 'react';

export function NotifyMe({ productId, variantId, size, onDone }: { productId: string; variantId: string; size: string; onDone: () => void }) {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setError('Please enter a valid email.');
      return;
    }
    setError(null);
    setLoading(true);
    const res = await fetch('/api/notify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, variantId, size, email }),
    });
    setLoading(false);
    if (res.ok) {
      setDone(true);
      setTimeout(onDone, 2000);
    } else {
      setError('Could not save — please try again.');
    }
  };

  if (done) {
    return (
      <p className="mt-4 rounded border border-ink-200 bg-ivory-100 p-3 text-sm">Thanks — we'll email you when size {size} is back.</p>
    );
  }

  return (
    <form onSubmit={submit} className="mt-4 flex flex-wrap gap-2 rounded border border-ink-200 bg-ivory-100 p-3">
      <label className="sr-only" htmlFor="notify-email">Email</label>
      <input id="notify-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="input flex-1" />
      <button disabled={loading} className="btn-secondary">{loading ? 'Saving…' : 'Notify me'}</button>
      {error ? <p className="basis-full text-xs text-red-700">{error}</p> : null}
    </form>
  );
}