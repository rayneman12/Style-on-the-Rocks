'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';

const KEY = 'sotr-cookie-consent';

export function CookieConsent() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    try {
      const v = localStorage.getItem(KEY);
      if (!v) setShow(true);
    } catch {}
  }, []);
  if (!show) return null;
  const accept = () => {
    try { localStorage.setItem(KEY, 'accepted'); } catch {}
    setShow(false);
  };
  const decline = () => {
    try { localStorage.setItem(KEY, 'declined'); } catch {}
    setShow(false);
  };
  return (
    <div className="fixed inset-x-3 bottom-3 z-30 mx-auto max-w-3xl border border-ink-200 bg-ivory-50 p-4 shadow-soft" role="dialog" aria-label="Cookie consent">
      <p className="text-sm">
        We use cookies for essential site functions and, with consent, for analytics. See our <Link href="/cookies" className="underline">cookie policy</Link> and <Link href="/privacy" className="underline">privacy notice</Link>.
      </p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button onClick={accept} className="btn-primary">Accept</button>
        <button onClick={decline} className="btn-secondary">Decline non-essential</button>
      </div>
    </div>
  );
}