/**
 * Stock — per-size inventory helpers.
 */

export type StockState = 'IN_STOCK' | 'LOW_STOCK' | 'SOLD_OUT';

export function stockState(stock: number, lowThreshold = 3): StockState {
  if (stock <= 0) return 'SOLD_OUT';
  if (stock <= lowThreshold) return 'LOW_STOCK';
  return 'IN_STOCK';
}

/** Decrement stock only if sufficient, returning whether the operation succeeded. */
export function tryDecrementStock(currentStock: number, qty: number): { ok: boolean; newStock: number } {
  if (currentStock < qty) return { ok: false, newStock: currentStock };
  return { ok: true, newStock: currentStock - qty };
}