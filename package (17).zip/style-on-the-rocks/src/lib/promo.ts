/**
 * Promo codes — pure logic. The DB lookup is the caller's responsibility.
 */
export type Promo = {
  code: string;
  type: 'PERCENT' | 'FIXED';
  value: number;
  minSubtotalCents: number;
  active: boolean;
  startsAt: Date | null;
  endsAt: Date | null;
  usageLimit: number | null;
  usedCount: number;
};

export type PromoResult =
  | { ok: true; discountCents: number; promo: Promo }
  | { ok: false; reason: string };

export function evaluatePromo(promo: Promo, subtotalCents: number, now: Date = new Date()): PromoResult {
  if (!promo.active) return { ok: false, reason: 'Promo code is inactive.' };
  if (promo.startsAt && now < promo.startsAt) return { ok: false, reason: 'Promo not yet active.' };
  if (promo.endsAt && now > promo.endsAt) return { ok: false, reason: 'Promo has expired.' };
  if (promo.usageLimit !== null && promo.usedCount >= promo.usageLimit) {
    return { ok: false, reason: 'Promo usage limit reached.' };
  }
  if (subtotalCents < promo.minSubtotalCents) {
    return {
      ok: false,
      reason: `Minimum spend ${promo.minSubtotalCents / 100} required.`,
    };
  }
  let discountCents = 0;
  if (promo.type === 'PERCENT') {
    discountCents = Math.floor((subtotalCents * promo.value) / 100);
  } else {
    discountCents = Math.min(subtotalCents, promo.value);
  }
  return { ok: true, discountCents, promo };
}