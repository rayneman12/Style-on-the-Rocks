/**
 * Shipping — config-driven. Until courier live rates are enabled,
 * the rate table below is used.
 */
import { siteConfig } from '@config/site.config';

export type DeliveryOption = {
  id: 'CLICK_COLLECT' | 'LOCAL' | 'COURIER';
  label: string;
  description: string;
  etaLabel: string;
  priceCents: number;
  freeOverCents?: number;
};

// Default courier rate table — these are sensible defaults.
// Owner can override by editing this file or via admin in future.
const COURIER_RATES: Record<string, { label: string; etaLabel: string; priceCents: number }> = {
  EC: { label: 'Courier — Eastern Cape', etaLabel: '3–5 business days', priceCents: 18000 },
  FS: { label: 'Courier — Free State', etaLabel: '3–5 business days', priceCents: 18000 },
  GP: { label: 'Courier — Gauteng', etaLabel: '2–4 business days', priceCents: 16000 },
  KZN: { label: 'Courier — KwaZulu-Natal', etaLabel: '1–3 business days', priceCents: 12000 },
  LP: { label: 'Courier — Limpopo', etaLabel: '3–5 business days', priceCents: 20000 },
  MP: { label: 'Courier — Mpumalanga', etaLabel: '3–5 business days', priceCents: 20000 },
  NC: { label: 'Courier — Northern Cape', etaLabel: '4–6 business days', priceCents: 22000 },
  NW: { label: 'Courier — North West', etaLabel: '3–5 business days', priceCents: 18000 },
  WC: { label: 'Courier — Western Cape', etaLabel: '3–5 business days', priceCents: 18000 },
};

export function getDeliveryOptions(subtotalCents: number, province: string): DeliveryOption[] {
  const free = siteConfig.commerce.freeDeliveryThresholdZAR * 100;
  const isOverFree = subtotalCents >= free;

  const opts: DeliveryOption[] = [
    {
      id: 'CLICK_COLLECT',
      label: 'Click & Collect',
      description: 'Collect from our Umhlanga Rocks boutique — free',
      etaLabel: 'Ready within 1 business day',
      priceCents: 0,
    },
    {
      id: 'LOCAL',
      label: 'Local delivery (Umhlanga / Durban)',
      description: 'Hand-delivered within the Umhlanga and greater Durban area',
      etaLabel: '1–2 business days',
      priceCents: isOverFree ? 0 : 8000,
      freeOverCents: free,
    },
  ];

  const provinceCode = (province || '').toUpperCase().slice(0, 2) as keyof typeof COURIER_RATES;
  const courier = COURIER_RATES[provinceCode] ?? {
    label: 'Courier — Nationwide',
    etaLabel: '2–5 business days',
    priceCents: 18000,
  };
  opts.push({
    id: 'COURIER',
    label: courier.label,
    description: 'Door-to-door courier with tracking',
    etaLabel: courier.etaLabel,
    priceCents: isOverFree ? 0 : courier.priceCents,
    freeOverCents: free,
  });

  return opts;
}

export function getShippingCost(optionId: string, subtotalCents: number, province: string): number {
  const opts = getDeliveryOptions(subtotalCents, province);
  return opts.find((o) => o.id === optionId)?.priceCents ?? 0;
}

export const SA_PROVINCES = [
  'Eastern Cape',
  'Free State',
  'Gauteng',
  'KwaZulu-Natal',
  'Limpopo',
  'Mpumalanga',
  'Northern Cape',
  'North West',
  'Western Cape',
] as const;

/** Validate a South African postcode (4 digits). */
export function isValidPostcode(pc: string): boolean {
  return /^\d{4}$/.test(String(pc).trim());
}