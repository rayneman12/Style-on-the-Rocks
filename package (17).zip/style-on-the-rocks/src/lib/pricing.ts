/**
 * Pricing — all amounts are stored in cents (integers).
 * Display formatting for ZAR ("R 1 250").
 */
import { siteConfig } from '@config/site.config';

export function formatZAR(cents: number): string {
  const rands = cents / 100;
  const fixed = rands.toFixed(0);
  // South African grouping: spaces, e.g. "R 1 250"
  const [intPart] = fixed.split('.');
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  return `R ${grouped}`;
}

export function randsToCents(rands: number): number {
  return Math.round(rands * 100);
}

export function applyDiscount(
  subtotalCents: number,
  type: 'PERCENT' | 'FIXED',
  value: number,
): number {
  if (type === 'PERCENT') {
    return Math.floor((subtotalCents * value) / 100);
  }
  return Math.min(subtotalCents, value);
}

/** Pure function for unit tests. */
export function computeTotals(args: {
  subtotalCents: number;
  shippingCents: number;
  discountCents: number;
  vatRate?: number;
}): { vatCents: number; totalCents: number } {
  const vatRate = args.vatRate ?? siteConfig.commerce.vatRate;
  // Prices are VAT-inclusive. We extract the VAT portion of the *chargeable*
  // amount (subtotal + shipping - discount).
  const chargeable = Math.max(
    0,
    args.subtotalCents + args.shippingCents - args.discountCents,
  );
  const vatCents = Math.round((chargeable * vatRate) / (1 + vatRate));
  const totalCents = chargeable;
  return { vatCents, totalCents };
}