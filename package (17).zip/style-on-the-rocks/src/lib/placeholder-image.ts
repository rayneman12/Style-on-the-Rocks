/**
 * Neutral product placeholder generator.
 * No stock photos of real designer brands — explicit per spec.
 *
 * Renders an inline SVG data URI: sand background with a subtle sea/ocean
 * accent band and a category label. Deterministic from a seed.
 */
export function placeholderImage({
  width = 800,
  height = 1000,
  label,
  seed = 1,
  variant = 'sand',
}: {
  width?: number;
  height?: number;
  label: string;
  seed?: number;
  variant?: 'sand' | 'ocean' | 'ivory' | 'brass';
}): string {
  const palette = {
    sand: { bg: '#EDE5D3', accent: '#A88A53', ink: '#3F3F3F' },
    ocean: { bg: '#BFD7DD', accent: '#0F3D4C', ink: '#0A0A0A' },
    ivory: { bg: '#F5F0E6', accent: '#A8854A', ink: '#111111' },
    brass: { bg: '#D9BC85', accent: '#5A3A1A', ink: '#1A1A1A' },
  }[variant];

  const offset = (seed * 73) % 200;
  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid slice">
  <rect width="${width}" height="${height}" fill="${palette.bg}"/>
  <rect x="0" y="${height - 280 + offset % 60}" width="${width}" height="280" fill="${palette.accent}" opacity="0.18"/>
  <rect x="${60 + (seed * 17) % 80}" y="${height - 360}" width="${width - 120}" height="2" fill="${palette.accent}" opacity="0.5"/>
  <text x="50%" y="48%" font-family="Cormorant Garamond, Georgia, serif" font-size="48" fill="${palette.ink}" text-anchor="middle" font-weight="500">${escapeXml(label)}</text>
  <text x="50%" y="55%" font-family="Inter, Helvetica, sans-serif" font-size="14" fill="${palette.ink}" text-anchor="middle" letter-spacing="3">SAMPLE</text>
  <text x="50%" y="${height - 40}" font-family="Inter, Helvetica, sans-serif" font-size="11" fill="${palette.ink}" text-anchor="middle" letter-spacing="3" opacity="0.6">STYLE ON THE ROCKS · SAMPLE IMAGE</text>
</svg>`.trim();

  const encoded = encodeURIComponent(svg)
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29');
  return `data:image/svg+xml;charset=utf-8,${encoded}`;
}

function escapeXml(s: string): string {
  return s.replace(/[<>&'"]/g, (c) => ({
    '<': '&lt;',
    '>': '&gt;',
    '&': '&amp;',
    "'": '&apos;',
    '"': '&quot;',
  })[c] ?? c);
}