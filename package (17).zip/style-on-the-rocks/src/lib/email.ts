/**
 * Email adapter — Resend when RESEND_API_KEY is set, otherwise logs to DB + console.
 * The /admin/emails page renders the preview from the EmailLog table.
 */
import { prisma } from './prisma';

export type EmailPayload = {
  to: string;
  subject: string;
  html: string;
  text?: string;
};

export async function sendEmail(payload: EmailPayload): Promise<{ ok: boolean; id?: string; error?: string }> {
  const apiKey = process.env.RESEND_API_KEY;
  if (apiKey) {
    try {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: `${process.env.EMAIL_FROM_NAME ?? 'Style on the Rocks'} <${process.env.EMAIL_FROM_ADDRESS ?? 'orders@styleontherocks.example'}>`,
          to: payload.to,
          subject: payload.subject,
          html: payload.html,
          text: payload.text ?? '',
        }),
      });
      const data = (await res.json()) as { id?: string; error?: string };
      await prisma.emailLog.create({
        data: {
          toAddress: payload.to,
          subject: payload.subject,
          body: payload.html,
          provider: 'RESEND',
          providerId: data.id ?? null,
        },
      });
      return { ok: res.ok, id: data.id, error: data.error };
    } catch (e) {
      await prisma.emailLog.create({
        data: {
          toAddress: payload.to,
          subject: payload.subject,
          body: payload.html,
          provider: 'RESEND',
        },
      });
      return { ok: false, error: String(e) };
    }
  }
  // Dev fallback — log to console + persist.
  // eslint-disable-next-line no-console
  console.log('\n[email:console]', payload.to, '·', payload.subject);
  await prisma.emailLog.create({
    data: {
      toAddress: payload.to,
      subject: payload.subject,
      body: payload.html,
      provider: 'CONSOLE',
    },
  });
  return { ok: true };
}