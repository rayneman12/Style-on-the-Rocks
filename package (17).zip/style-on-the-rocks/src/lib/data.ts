import { prisma } from './prisma';
import type { Prisma } from '@prisma/client';

export type ProductListItem = Awaited<ReturnType<typeof listProducts>>[number];

export async function listProducts(opts?: {
  where?: Prisma.ProductWhereInput;
  take?: number;
  orderBy?: Prisma.ProductOrderByWithRelationInput;
}) {
  const products = await prisma.product.findMany({
    where: { status: 'ACTIVE', ...(opts?.where ?? {}) },
    orderBy: opts?.orderBy ?? { createdAt: 'desc' },
    take: opts?.take,
    include: {
      images: { orderBy: { position: 'asc' }, take: 1 },
      variants: true,
      brand: true,
      category: true,
    },
  });
  return products.map((p) => shapeProduct(p));
}

export async function getProductBySlug(slug: string) {
  const product = await prisma.product.findUnique({
    where: { slug },
    include: {
      images: { orderBy: { position: 'asc' } },
      variants: true,
      brand: true,
      category: true,
    },
  });
  return product ? shapeProduct(product, true) : null;
}

export async function listCategories() {
  return prisma.category.findMany({ orderBy: { position: 'asc' } });
}

export async function listBrands() {
  return prisma.brand.findMany({ orderBy: { name: 'asc' } });
}

export async function listJournalPosts() {
  return prisma.journalPost.findMany({
    where: { published: true },
    orderBy: { publishedAt: 'desc' },
    take: 24,
  });
}

export async function getJournalPost(slug: string) {
  return prisma.journalPost.findUnique({ where: { slug } });
}

export async function getCompleteTheLook(slugs: string[]) {
  if (!slugs.length) return [];
  const products = await prisma.product.findMany({
    where: { slug: { in: slugs }, status: 'ACTIVE' },
    include: { images: { take: 1 }, brand: true, category: true },
  });
  return products.map((p) => shapeProduct(p));
}

export async function getRecentlyViewed(slugs: string[]) {
  if (!slugs.length) return [];
  const products = await prisma.product.findMany({
    where: { slug: { in: slugs }, status: 'ACTIVE' },
    take: 8,
    include: { images: { take: 1 }, brand: true, category: true },
  });
  return products.map((p) => shapeProduct(p));
}

function shapeProduct(
  p: any,
  includeAllImages = false,
): {
  id: string;
  slug: string;
  name: string;
  description: string;
  shortDescription: string | null;
  priceCents: number;
  compareAtCents: number | null;
  sku: string;
  isNew: boolean;
  isOnSale: boolean;
  status: string;
  brand: { id: string; slug: string; name: string };
  category: { id: string; slug: string; name: string };
  images: { url: string; alt: string; position: number }[];
  variants: { id: string; size: string; color: string | null; stock: number }[];
  minStock: number;
} {
  const minStock = p.variants?.length
    ? Math.min(...p.variants.map((v: any) => v.stock))
    : 0;
  return {
    id: p.id,
    slug: p.slug,
    name: p.name,
    description: p.description,
    shortDescription: p.shortDescription ?? null,
    priceCents: p.priceCents,
    compareAtCents: p.compareAtCents ?? null,
    sku: p.sku,
    isNew: p.isNew,
    isOnSale: p.isOnSale,
    status: p.status,
    brand: { id: p.brand.id, slug: p.brand.slug, name: p.brand.name },
    category: { id: p.category.id, slug: p.category.slug, name: p.category.name },
    images: includeAllImages ? p.images : p.images?.slice(0, 1) ?? [],
    variants: p.variants ?? [],
    minStock,
  };
}