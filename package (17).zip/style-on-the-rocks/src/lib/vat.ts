/**
 * VAT — South Africa standard rate is 15%, included in display prices.
 */
import { siteConfig } from '@config/site.config';

export const VAT_RATE = siteConfig.commerce.vatRate;

/** Extract VAT from a VAT-inclusive amount in cents. */
export function vatInclusive(amountCents: number): number {
  return Math.round((amountCents * VAT_RATE) / (1 + VAT_RATE));
}

/** Verify a server-computed total matches what the client submitted. */
export function totalsMatch(server: number, client: number): boolean {
  // Allow 1 cent rounding tolerance
  return Math.abs(server - client) <= 1;
}