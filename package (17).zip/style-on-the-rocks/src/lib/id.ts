/** Generate a cuid-like ID without an extra dep. */
import { randomBytes } from 'crypto';

export function newId(prefix = ''): string {
  const ts = Date.now().toString(36);
  const rnd = randomBytes(8).toString('hex');
  return `${prefix}${ts}${rnd}`;
}