import { listProducts, listCategories } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { notFound } from 'next/navigation';

export async function generateStaticParams() {
  const cats = await listCategories();
  return cats.map((c) => ({ category: c.slug }));
}

export async function generateMetadata({ params }: { params: { category: string } }) {
  return { title: params.category.replace(/-/g, ' ') };
}

export default async function CategoryPage({ params }: { params: { category: string } }) {
  const cats = await listCategories();
  const cat = cats.find((c) => c.slug === params.category);
  if (!cat) notFound();
  const products = await listProducts({ where: { category: { slug: params.category } } });
  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">Shop</p>
        <h1 className="h-section mt-2">{cat.name}</h1>
      </header>
      {products.length === 0 ? (
        <p className="text-sm text-ink-500">No products yet in this category.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}