import Link from 'next/link';
import { listProducts, listCategories } from '@/lib/data';
import { ShopGrid } from './shop-grid';
import { Filters } from './filters';

export const dynamic = 'force-static';
export const metadata = { title: 'Shop' };

export default async function ShopPage() {
  // Static export: render the full product catalogue at build time and let
  // the client-side grid handle filtering/sorting against the URL.
  const [cats, products] = await Promise.all([listCategories(), listProducts({ take: 200 })]);

  return (
    <div className="container-x py-10">
      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Shop</p>
          <h1 className="h-section mt-2">All</h1>
        </div>
        <div className="flex flex-wrap gap-2">
          {cats.slice(0, 6).map((c) => (
            <Link
              key={c.id}
              href={`/shop/${c.slug}`}
              className="text-xs uppercase tracking-wider2 px-3 py-1 border border-ink-200 hover:border-ink"
            >
              {c.name}
            </Link>
          ))}
        </div>
      </header>
      <div className="grid gap-8 md:grid-cols-[260px_1fr]">
        <Filters />
        <ShopGrid products={products as any} />
      </div>
    </div>
  );
}
