'use client';
import { useSearchParams } from 'next/navigation';
import { useMemo } from 'react';
import { ProductCard, type ProductCardData } from '@/components/product-card';

type Product = ProductCardData & {
  id: string;
  variants: { id: string; size: string; color: string | null; stock: number }[];
  brand: { slug: string };
  category: { slug: string };
};

export function ShopGrid({ products }: { products: Product[] }) {
  const sp = useSearchParams();

  const filtered = useMemo(() => {
    let out = products;
    const category = sp.get('category');
    const brand = sp.get('brand');
    const onSale = sp.get('onSale');
    const inStock = sp.get('inStock');
    const size = sp.get('size');
    const priceMin = sp.get('priceMin');
    const priceMax = sp.get('priceMax');
    const sort = sp.get('sort');

    if (category) out = out.filter((p) => p.category.slug === category);
    if (brand) out = out.filter((p) => p.brand.slug === brand);
    if (onSale === '1') out = out.filter((p) => p.isOnSale);
    if (inStock === '1') out = out.filter((p) => (p.minStock ?? 0) > 0);
    if (size) out = out.filter((p) => p.variants?.some((v) => v.size === size));
    if (priceMin) out = out.filter((p) => p.priceCents >= Number(priceMin) * 100);
    if (priceMax) out = out.filter((p) => p.priceCents <= Number(priceMax) * 100);

    if (sort === 'price-asc') out = [...out].sort((a, b) => a.priceCents - b.priceCents);
    if (sort === 'price-desc') out = [...out].sort((a, b) => b.priceCents - a.priceCents);

    return out;
  }, [products, sp]);

  if (filtered.length === 0) {
    return <p className="text-sm text-ink-500">No products match these filters.</p>;
  }
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
      {filtered.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}
