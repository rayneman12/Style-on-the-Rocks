'use client';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState, useEffect } from 'react';

const SIZES = ['XS', 'S', 'M', 'L', 'XL', '28', '30', '32', '34', '36', '6', '7', '8', '9', '10', '11', 'One', '50ml', '200ml'];

export function Filters() {
  const router = useRouter();
  const sp = useSearchParams();
  const [state, setState] = useState({
    size: sp.get('size') ?? '',
    brand: sp.get('brand') ?? '',
    priceMin: sp.get('priceMin') ?? '',
    priceMax: sp.get('priceMax') ?? '',
    onSale: sp.get('onSale') ?? '',
    inStock: sp.get('inStock') ?? '',
    sort: sp.get('sort') ?? '',
  });
  useEffect(() => {
    setState({
      size: sp.get('size') ?? '',
      brand: sp.get('brand') ?? '',
      priceMin: sp.get('priceMin') ?? '',
      priceMax: sp.get('priceMax') ?? '',
      onSale: sp.get('onSale') ?? '',
      inStock: sp.get('inStock') ?? '',
      sort: sp.get('sort') ?? '',
    });
  }, [sp]);

  const apply = (patch: Record<string, string>) => {
    const next = { ...state, ...patch };
    setState(next);
    const params = new URLSearchParams();
    Object.entries(next).forEach(([k, v]) => { if (v) params.set(k, v); });
    router.push(`/shop?${params.toString()}`);
  };

  return (
    <aside className="space-y-6" aria-label="Filters">
      <div>
        <p className="label">Sort</p>
        <select value={state.sort} onChange={(e) => apply({ sort: e.target.value })} className="input">
          <option value="">Featured</option>
          <option value="new">Newest</option>
          <option value="price-asc">Price · low to high</option>
          <option value="price-desc">Price · high to low</option>
        </select>
      </div>
      <div>
        <p className="label">Size</p>
        <div className="flex flex-wrap gap-1">
          {SIZES.map((s) => (
            <button
              key={s}
              onClick={() => apply({ size: state.size === s ? '' : s })}
              className={`h-8 min-w-8 border px-2 text-xs ${state.size === s ? 'bg-ink text-ivory-50 border-ink' : 'border-ink-200 hover:border-ink'}`}
              aria-pressed={state.size === s}
            >
              {s}
            </button>
          ))}
        </div>
      </div>
      <div>
        <p className="label">Price (R)</p>
        <div className="flex gap-2">
          <input value={state.priceMin} onChange={(e) => setState({ ...state, priceMin: e.target.value })} placeholder="Min" className="input" inputMode="numeric" />
          <input value={state.priceMax} onChange={(e) => setState({ ...state, priceMax: e.target.value })} placeholder="Max" className="input" inputMode="numeric" />
        </div>
        <button onClick={() => apply({})} className="btn-secondary mt-2 w-full">Apply price</button>
      </div>
      <div className="space-y-2">
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={state.onSale === '1'} onChange={(e) => apply({ onSale: e.target.checked ? '1' : '' })} />
          On sale
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={state.inStock === '1'} onChange={(e) => apply({ inStock: e.target.checked ? '1' : '' })} />
          In stock only
        </label>
      </div>
      <button
        onClick={() => router.push('/shop')}
        className="text-xs uppercase tracking-wider2 text-ink-500 underline-offset-4 hover:underline"
      >
        Reset filters
      </button>
    </aside>
  );
}