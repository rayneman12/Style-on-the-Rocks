export const metadata = { title: 'FAQ' };

const FAQ: Array<{ q: string; a: string }> = [
  {
    q: 'How long does delivery take?',
    a: 'Click & Collect is ready within 1 business day. Local Umhlanga / Durban delivery is 1–2 business days. Courier is 2–5 business days depending on province.',
  },
  {
    q: 'Do you ship internationally?',
    a: 'Not at the moment. We ship nationwide within South Africa.',
  },
  {
    q: 'Can I change or cancel my order?',
    a: 'Email us within 2 hours of placing the order and we\'ll do our best. Once an order is packed for collection or dispatched, we can no longer change it.',
  },
  {
    q: 'What payment methods do you accept?',
    a: 'PayFast (cards and instant EFT), EFT, and pay-on-collection.',
  },
  {
    q: 'Is VAT included in the price?',
    a: 'Yes — all prices on the site are VAT-inclusive at 15%.',
  },
  {
    q: 'Do you offer personal styling?',
    a: 'Yes — book a complimentary 45-minute session at our Umhlanga Rocks boutique. See the Book a stylist page.',
  },
  {
    q: 'What if my size is out of stock?',
    a: 'Use the "Notify me" button on the product page and we\'ll email when it\'s back.',
  },
  {
    q: 'Do you have gift cards?',
    a: 'Yes — see the Gift cards page. Digital only, no expiry, redeemable in-store and online.',
  },
];

export default function FaqPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Help</p>
      <h1 className="h-section mt-2">Frequently asked questions</h1>

      <div className="mt-10 space-y-6">
        {FAQ.map((item) => (
          <details key={item.q} className="group border-b border-ink-200 pb-5">
            <summary className="flex cursor-pointer list-none items-center justify-between font-serif text-xl">
              <span>{item.q}</span>
              <span aria-hidden className="ml-4 text-ink-500 transition-transform group-open:rotate-45">+</span>
            </summary>
            <p className="mt-3 text-ink-700">{item.a}</p>
          </details>
        ))}
      </div>

      <p className="mt-10 text-sm text-ink-500">
        Don't see your question? <a href="/contact" className="underline">Get in touch</a>.
      </p>
    </div>
  );
}
