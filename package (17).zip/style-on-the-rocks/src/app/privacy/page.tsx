export const metadata = { title: 'Privacy' };

export default function PrivacyPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Legal</p>
      <h1 className="h-section mt-2">Privacy notice</h1>
      <p className="mt-3 text-sm text-ink-500">Last updated: this build.</p>

      <h2 className="font-serif text-2xl mt-10">What we collect</h2>
      <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-700">
        <li>Order details — name, email, phone, shipping address, items purchased.</li>
        <li>Account details — if you create an account, your email and a hashed password.</li>
        <li>Newsletter signups — your email and confirmation status.</li>
        <li>Anonymous analytics — aggregated page views, no personal identifiers.</li>
      </ul>

      <h2 className="font-serif text-2xl mt-8">How we use it</h2>
      <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-700">
        <li>To process and deliver your order, and to send related emails (confirmation, dispatch, returns).</li>
        <li>To improve the site and merchandising.</li>
        <li>To send our newsletter, only if you've subscribed.</li>
      </ul>

      <h2 className="font-serif text-2xl mt-8">Third parties</h2>
      <p className="mt-2 text-ink-700">
        We share data only with services that help us run the business: PayFast (payments), our courier
        (shipping label), and our email provider. None of them use the data for their own marketing.
      </p>

      <h2 className="font-serif text-2xl mt-8">Your rights</h2>
      <p className="mt-2 text-ink-700">
        Under POPIA you can request a copy of your data, ask us to correct it, or request its deletion.
        Email us to make a request.
      </p>

      <h2 className="font-serif text-2xl mt-8">Cookies</h2>
      <p className="mt-2 text-ink-700">
        See our <a href="/cookies" className="underline">Cookies notice</a>.
      </p>
    </div>
  );
}
