'use client';
import { useState } from 'react';
import { siteConfig } from '@config/site.config';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Demo-only: in production wire this to a real endpoint.
    await new Promise((r) => setTimeout(r, 600));
    setSent(true);
    setSubmitting(false);
  };

  return (
    <div className="container-x py-12 md:py-16">
      <p className="eyebrow">Contact</p>
      <h1 className="h-section mt-2">Get in touch</h1>
      <p className="mt-3 max-w-prose text-ink-600">
        Questions about an order, a product, or just want to chat about a piece? Send us a note.
      </p>

      <div className="mt-10 grid gap-10 md:grid-cols-[3fr_2fr]">
        {sent ? (
          <div className="border border-ocean bg-ocean/5 p-6 text-sm">
            <p className="font-medium">Thanks — message received.</p>
            <p className="mt-1 text-ink-600">We'll get back to you within one business day.</p>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label htmlFor="name" className="label">Name *</label>
              <input id="name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" />
            </div>
            <div>
              <label htmlFor="email" className="label">Email *</label>
              <input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" />
            </div>
            <div>
              <label htmlFor="message" className="label">Message *</label>
              <textarea id="message" required rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="input" />
            </div>
            <button type="submit" disabled={submitting} className="btn-primary">
              {submitting ? 'Sending…' : 'Send message'}
            </button>
            <p className="text-xs text-ink-500">
              This form is a demo placeholder — wire to a real endpoint in production.
            </p>
          </form>
        )}

        <aside className="h-fit border border-ink-200 bg-ivory-100 p-6 text-sm">
          <p className="eyebrow">Direct</p>
          <ul className="mt-3 space-y-2">
            <li>
              <span className="text-ink-500">Email — </span>
              {siteConfig.contact.email ?? <span className="text-ink-400">to be supplied</span>}
            </li>
            <li>
              <span className="text-ink-500">Phone — </span>
              {siteConfig.contact.phone ?? <span className="text-ink-400">to be supplied</span>}
            </li>
            <li>
              <span className="text-ink-500">WhatsApp — </span>
              {siteConfig.contact.whatsapp ?? <span className="text-ink-400">to be supplied</span>}
            </li>
          </ul>
          <p className="eyebrow mt-6">Follow</p>
          <ul className="mt-3 space-y-2">
            <li><a href={siteConfig.contact.instagram} target="_blank" rel="noopener noreferrer" className="underline">Instagram</a></li>
            <li><a href={siteConfig.contact.facebook} target="_blank" rel="noopener noreferrer" className="underline">Facebook</a></li>
            <li><a href={siteConfig.contact.tiktok} target="_blank" rel="noopener noreferrer" className="underline">TikTok</a></li>
          </ul>
        </aside>
      </div>
    </div>
  );
}
