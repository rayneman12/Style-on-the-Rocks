'use client';
import { useState, useMemo, useEffect } from 'react';
import { formatZAR } from '@/lib/pricing';
import { stockState } from '@/lib/stock';
import { useCart } from '@/stores/cart';
import { useWishlist } from '@/stores/wishlist';
import { siteConfig, whatsappEnabled } from '@config/site.config';
import { SizeGuide } from '@/components/size-guide';
import { NotifyMe } from '@/components/notify-me';

type Product = {
  id: string;
  slug: string;
  name: string;
  description: string;
  shortDescription: string | null;
  priceCents: number;
  compareAtCents: number | null;
  sku: string;
  isNew: boolean;
  isOnSale: boolean;
  brand: { name: string; slug: string };
  category: { name: string; slug: string };
  images: { url: string; alt: string; position: number }[];
  variants: { id: string; size: string; color: string | null; stock: number }[];
  minStock: number;
};

export function ProductDetail({ product }: { product: Product }) {
  const [size, setSize] = useState<string | null>(null);
  const [imageIdx, setImageIdx] = useState(0);
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);
  const [showNotify, setShowNotify] = useState(false);

  const addLine = useCart((s) => s.add);
  const openCart = (useCart as any).__zustand_store ? null : null; // not used
  const openCartFn = () => {
    // trigger the cart drawer via custom event
    window.dispatchEvent(new CustomEvent('sotr:open-cart'));
  };
  const wishlistHas = useWishlist((s) => s.has);
  const wishlistToggle = useWishlist((s) => s.toggle);

  useEffect(() => {
    // Persist to recently viewed
    try {
      const KEY = 'sotr-recent';
      const arr = JSON.parse(localStorage.getItem(KEY) ?? '[]') as string[];
      const next = [product.slug, ...arr.filter((s) => s !== product.slug)].slice(0, 8);
      localStorage.setItem(KEY, JSON.stringify(next));
    } catch {}
  }, [product.slug]);

  const sizes = useMemo(() => {
    const map = new Map<string, number>();
    for (const v of product.variants) {
      map.set(v.size, (map.get(v.size) ?? 0) + v.stock);
    }
    return Array.from(map.entries()).map(([size, stock]) => ({ size, stock }));
  }, [product.variants]);

  const selectedVariant = product.variants.find((v) => v.size === size);
  const selectedState = selectedVariant ? stockState(selectedVariant.stock) : null;
  const overallState = stockState(product.minStock);

  const wa = whatsappEnabled();
  const waLink = wa && size ? buildWaLink(product, size) : null;

  const add = () => {
    if (!selectedVariant || selectedVariant.stock <= 0 || !size) return;
    setAdding(true);
    addLine({
      productId: product.id,
      productSlug: product.slug,
      productName: product.name,
      size,
      unitPriceCents: product.priceCents,
      quantity: 1,
      image: product.images[0]?.url,
    });
    setAdding(false);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
    window.dispatchEvent(new CustomEvent('sotr:open-cart'));
  };

  return (
    <article className="container-x grid gap-10 py-10 md:grid-cols-2 md:gap-16">
      {/* Gallery */}
      <div className="space-y-3">
        <div className="aspect-[4/5] overflow-hidden bg-ivory-200">
          {product.images[imageIdx] ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.images[imageIdx].url} alt={product.images[imageIdx].alt || product.name} className="h-full w-full object-cover" />
          ) : null}
        </div>
        {product.images.length > 1 ? (
          <div className="flex gap-2">
            {product.images.map((img, i) => (
              <button
                key={img.url}
                onClick={() => setImageIdx(i)}
                aria-label={`View image ${i + 1}`}
                className={`h-16 w-16 overflow-hidden border ${i === imageIdx ? 'border-ink' : 'border-ink-200'}`}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={img.url} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        ) : null}
      </div>

      {/* Info */}
      <div>
        <p className="eyebrow">{product.brand.name} · {product.category.name}</p>
        <h1 className="h-section mt-2">{product.name}</h1>
        <p className="mt-3 text-sm text-ink-500">SKU: {product.sku}</p>
        <div className="mt-4 flex items-baseline gap-3">
          {product.isOnSale && product.compareAtCents ? (
            <span className="text-ink-400 line-through">{formatZAR(product.compareAtCents)}</span>
          ) : null}
          <span className="font-serif text-2xl">{formatZAR(product.priceCents)}</span>
          <span className="text-xs text-ink-500">VAT incl.</span>
        </div>
        {product.shortDescription ? (
          <p className="mt-6 max-w-prose text-sm leading-relaxed">{product.shortDescription}</p>
        ) : null}
        <p className="mt-4 max-w-prose text-sm leading-relaxed text-ink-700">{product.description}</p>

        {/* Sizes */}
        <div className="mt-8">
          <div className="mb-2 flex items-center justify-between">
            <p className="label">Size</p>
            <SizeGuideButton />
          </div>
          <div className="flex flex-wrap gap-2">
            {sizes.map(({ size: sz, stock }) => {
              const state = stockState(stock);
              return (
                <button
                  key={sz}
                  onClick={() => setSize(sz)}
                  disabled={state === 'SOLD_OUT'}
                  className={`min-w-12 border px-3 py-2 text-sm transition-colors ${
                    size === sz
                      ? 'border-ink bg-ink text-ivory-50'
                      : 'border-ink-200 hover:border-ink'
                  } ${state === 'SOLD_OUT' ? 'opacity-40 line-through cursor-not-allowed' : ''}`}
                  aria-pressed={size === sz}
                >
                  {sz}
                </button>
              );
            })}
          </div>
          {!size ? (
            <p className="mt-2 text-xs text-ink-500">Select a size to add to bag.</p>
          ) : selectedState === 'LOW_STOCK' ? (
            <p className="mt-2 text-xs text-brass">Low stock — only {selectedVariant?.stock} left.</p>
          ) : selectedState === 'SOLD_OUT' ? (
            <p className="mt-2 text-xs text-ink-500">Sold out in this size.</p>
          ) : null}
        </div>

        {/* Add to bag */}
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <button
            onClick={add}
            disabled={!selectedVariant || selectedVariant.stock <= 0 || adding}
            className="btn-primary"
          >
            {added ? 'Added to bag' : adding ? 'Adding…' : overallState === 'SOLD_OUT' && !size ? 'Sold out' : 'Add to bag'}
          </button>
          {selectedState === 'SOLD_OUT' ? (
            <button onClick={() => setShowNotify(true)} className="btn-secondary">Notify me</button>
          ) : null}
          <button
            onClick={() => wishlistToggle(product.id)}
            className="btn-ghost"
            aria-pressed={wishlistHas(product.id)}
          >
            {wishlistHas(product.id) ? '♥ In wishlist' : '♡ Wishlist'}
          </button>
        </div>
        {showNotify && size ? (
          <NotifyMe productId={product.id} variantId={selectedVariant?.id ?? ''} size={size} onDone={() => setShowNotify(false)} />
        ) : null}

        {/* WhatsApp */}
        {waLink ? (
          <a
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-secondary mt-4 w-full"
          >
            Order on WhatsApp
          </a>
        ) : null}

        {/* Notes */}
        <div className="mt-10 grid grid-cols-2 gap-6 border-t border-ink-200 pt-6 text-xs text-ink-500">
          <div>
            <p className="eyebrow text-ink-700">Click & Collect</p>
            <p className="mt-1">Free from our Umhlanga Rocks boutique.</p>
          </div>
          <div>
            <p className="eyebrow text-ink-700">Returns</p>
            <p className="mt-1">30-day exchange on unworn stock. See our <a href="/returns" className="underline">returns policy</a>.</p>
          </div>
        </div>
      </div>
    </article>
  );
}

function SizeGuideButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)} className="text-xs uppercase tracking-wider2 underline-offset-4 hover:underline">Size guide</button>
      {open ? <SizeGuide onClose={() => setOpen(false)} /> : null}
    </>
  );
}

function buildWaLink(product: Product, size: string): string {
  const num = siteConfig.contact.whatsapp ?? '';
  const text = encodeURIComponent(`Hi Style on the Rocks, I'd like to order:\n${product.name}\nSize ${size}\n${process.env.NEXT_PUBLIC_APP_URL ?? ''}/product/${product.slug}`);
  return `https://wa.me/${num}?text=${text}`;
}