import { getProductBySlug, getCompleteTheLook, listProducts } from '@/lib/data';
import { notFound } from 'next/navigation';
import { ProductDetail } from './product-detail';
import { RecentlyViewed } from '@/components/recently-viewed';
import { ProductCard } from '@/components/product-card';
import { siteConfig } from '@config/site.config';

export async function generateStaticParams() {
  const products = await listProducts({});
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: { slug: string } }) {
  const p = await getProductBySlug(params.slug);
  if (!p) return { title: 'Product' };
  return {
    title: p.name,
    description: p.shortDescription ?? p.description.slice(0, 160),
    openGraph: {
      title: p.name,
      description: p.shortDescription ?? p.description.slice(0, 160),
      images: p.images.map((i) => i.url),
    },
  };
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug);
  if (!product) notFound();
  const completeSlugs = (product as any).completeTheLookCsv ? (product as any).completeTheLookCsv.split(',').filter(Boolean) : [];
  const complete = await getCompleteTheLook(completeSlugs);

  // JSON-LD Product schema
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    sku: product.sku,
    description: product.description,
    image: product.images.map((i) => i.url),
    brand: { '@type': 'Brand', name: product.brand.name },
    offers: {
      '@type': 'Offer',
      priceCurrency: 'ZAR',
      price: (product.priceCents / 100).toFixed(2),
      availability: product.minStock > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
      url: `${siteConfig.location ? '' : ''}${process.env.NEXT_PUBLIC_APP_URL ?? ''}/product/${product.slug}`,
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <ProductDetail product={product} />
      {complete.length > 0 ? (
        <section className="container-x py-16">
          <h2 className="h-section mb-6">Complete the look</h2>
          <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
            {complete.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      ) : null}
      <RecentlyViewed currentSlug={product.slug} />
    </>
  );
}