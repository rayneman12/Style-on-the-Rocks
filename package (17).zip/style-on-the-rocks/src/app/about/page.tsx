import { siteConfig } from '@config/site.config';

export const metadata = { title: 'About' };

export default function AboutPage() {
  return (
    <div className="container-x py-12 md:py-16">
      <div className="grid gap-10 md:grid-cols-[3fr_2fr]">
        <div>
          <p className="eyebrow">About</p>
          <h1 className="h-section mt-2">{siteConfig.brand.name}</h1>
          <p className="mt-4 max-w-prose text-lg text-ink-700">
            {siteConfig.brand.description}
          </p>
          <div className="mt-8 space-y-4 font-serif text-lg leading-relaxed text-ink-700">
            <p>
              We're a small boutique in {siteConfig.location.city}, {siteConfig.location.province},
              stocking a tightly edited selection of clothing, shoes, bags and accessories for women and men.
            </p>
            <p>
              Our buying is shaped by the coast — soft tailoring, easy pieces that travel well, and
              things we want to wear ourselves. We work with a small set of suppliers we know personally,
              and we'd rather turn down a piece than stock something we wouldn't put on ourselves.
            </p>
            <p>
              The site is an extension of the boutique — same edit, same people, same care with your order.
              You can collect from us, have it hand-delivered locally, or have it couriered nationwide.
            </p>
          </div>
        </div>
        <aside className="h-fit border border-ink-200 bg-ivory-100 p-6">
          <p className="eyebrow">Visit</p>
          <p className="mt-2 text-sm">{siteConfig.location.boutique}</p>
          <p className="mt-3 text-sm">
            See <a className="underline" href="/visit-us">Visit us</a> for address and hours.
          </p>
          <p className="eyebrow mt-6">Talk to us</p>
          <ul className="mt-2 text-sm">
            <li><a className="underline" href="/contact">Contact form</a></li>
            <li><a className="underline" href="/book-a-stylist">Book a stylist</a></li>
          </ul>
        </aside>
      </div>
    </div>
  );
}
