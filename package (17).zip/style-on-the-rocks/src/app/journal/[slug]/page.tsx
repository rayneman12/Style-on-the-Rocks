import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';

export const dynamic = 'force-static';

export async function generateStaticParams() {
  const posts = await prisma.journalPost.findMany({ where: { published: true }, select: { slug: true } });
  return posts.map((p) => ({ slug: p.slug }));
}

export default async function JournalPostPage({ params }: { params: { slug: string } }) {
  const post = await prisma.journalPost.findUnique({ where: { slug: params.slug } });
  if (!post || !post.published) notFound();

  return (
    <article className="container-x max-w-prose2 py-12 md:py-16">
      <Link href="/journal" className="text-sm text-ink-500 hover:text-ocean">← Journal</Link>
      <p className="eyebrow mt-6">{post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' }) : ''}</p>
      <h1 className="h-section mt-2">{post.title}</h1>
      <p className="mt-3 text-lg text-ink-600">{post.excerpt}</p>
      {post.coverImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={post.coverImage} alt="" className="mt-8 w-full" />
      ) : null}
      <div className="prose prose-neutral mt-10 max-w-none whitespace-pre-line font-serif text-lg leading-relaxed text-ink-700">
        {post.body}
      </div>
    </article>
  );
}
