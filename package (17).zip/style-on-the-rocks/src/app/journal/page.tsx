import Link from 'next/link';
import { listJournalPosts } from '@/lib/data';

export const revalidate = 60;

export default async function JournalIndex() {
  const posts = await listJournalPosts();
  return (
    <div className="container-x py-12">
      <p className="eyebrow">Journal</p>
      <h1 className="h-section mt-2">From the journal</h1>
      <p className="mt-3 max-w-prose text-ink-600">
        Editorial notes on coastal dressing, what we're working on, and the people we work with.
      </p>

      {posts.length === 0 ? (
        <p className="mt-12 text-sm text-ink-500">No posts yet.</p>
      ) : (
        <div className="mt-10 grid gap-10 md:grid-cols-3">
          {posts.map((post) => (
            <Link key={post.id} href={`/journal/${post.slug}`} className="group">
              <div className="aspect-[4/3] overflow-hidden bg-ivory-200">
                {post.coverImage ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={post.coverImage} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                ) : null}
              </div>
              <p className="eyebrow mt-3">{post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' }) : ''}</p>
              <h2 className="h-card mt-1 group-hover:text-ocean">{post.title}</h2>
              <p className="mt-2 text-sm text-ink-600">{post.excerpt}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
