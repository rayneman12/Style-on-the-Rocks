'use client';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/stores/cart';
import { formatZAR } from '@/lib/pricing';
import { computeTotals } from '@/lib/pricing';
import { SA_PROVINCES, isValidPostcode, getDeliveryOptions } from '@/lib/shipping';
import { siteConfig, whatsappEnabled } from '@config/site.config';

type FormState = {
  email: string;
  fullName: string;
  phone: string;
  line1: string;
  line2: string;
  suburb: string;
  city: string;
  province: string;
  postcode: string;
  deliveryOption: 'CLICK_COLLECT' | 'LOCAL' | 'COURIER';
  paymentMethod: 'PAYFAST' | 'EFT' | 'COLLECTION';
  notes: string;
};

const EMPTY: FormState = {
  email: '',
  fullName: '',
  phone: '',
  line1: '',
  line2: '',
  suburb: '',
  city: '',
  province: 'KwaZulu-Natal',
  postcode: '',
  deliveryOption: 'COURIER',
  paymentMethod: 'PAYFAST',
  notes: '',
};

export default function CheckoutPage() {
  const router = useRouter();
  const lines = useCart((s) => s.lines);
  const clear = useCart((s) => s.clear);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);

  const subtotal = useMemo(() => lines.reduce((a, l) => a + l.unitPriceCents * l.quantity, 0), [lines]);
  const shippingCents = useMemo(() => {
    const opts = getDeliveryOptions(subtotal, form.province);
    return opts.find((o) => o.id === form.deliveryOption)?.priceCents ?? 0;
  }, [subtotal, form.province, form.deliveryOption]);

  const promo = useMemo(() => {
    if (typeof window === 'undefined') return { code: null as string | null, discountCents: 0 };
    try {
      const raw = sessionStorage.getItem('sotr-promo');
      if (!raw) return { code: null, discountCents: 0 };
      return JSON.parse(raw);
    } catch { return { code: null, discountCents: 0 }; }
  }, [submitting]);

  const totals = useMemo(
    () => computeTotals({ subtotalCents: subtotal, shippingCents, discountCents: promo.discountCents }),
    [subtotal, shippingCents, promo.discountCents],
  );

  useEffect(() => {
    // localStorage prefill
    try {
      const raw = localStorage.getItem('sotr-checkout');
      if (raw) setForm((f) => ({ ...f, ...JSON.parse(raw) }));
    } catch {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem('sotr-checkout', JSON.stringify(form)); } catch {}
  }, [form]);

  if (!lines.length) {
    return (
      <div className="container-x py-16 text-center">
        <h1 className="h-section">Nothing to check out</h1>
        <p className="mt-2 text-sm text-ink-500">Your bag is empty.</p>
        <a href="/shop" className="btn-secondary mt-4">Browse</a>
      </div>
    );
  }

  const setField = <K extends keyof FormState>(k: K, v: FormState[K]) => setForm((f) => ({ ...f, [k]: v }));

  const validate = (): Record<string, string> => {
    const e: Record<string, string> = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email.';
    if (!form.fullName.trim()) e.fullName = 'Required.';
    if (form.deliveryOption !== 'CLICK_COLLECT') {
      if (!form.line1.trim()) e.line1 = 'Required.';
      if (!form.city.trim()) e.city = 'Required.';
      if (!SA_PROVINCES.includes(form.province as any)) e.province = 'Choose a province.';
      if (!isValidPostcode(form.postcode)) e.postcode = 'Enter a valid 4-digit SA postcode.';
    }
    return e;
  };

  const submit = async (ev: React.FormEvent) => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    setSubmitting(true);
    setServerError(null);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          items: lines,
          promoCode: promo.code,
          // Server will recompute — these are advisory only.
          clientSubtotalCents: subtotal,
          clientShippingCents: shippingCents,
          clientDiscountCents: promo.discountCents,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? 'Order could not be created.');
      // data: { orderId, paymentUrl? }
      if (data.paymentMethod === 'PAYFAST' && data.paymentUrl) {
        // Clear cart and redirect
        clear();
        sessionStorage.removeItem('sotr-promo');
        localStorage.removeItem('sotr-checkout');
        window.location.href = data.paymentUrl;
        return;
      }
      // For EFT / COLLECTION, just go to the confirmation page.
      clear();
      sessionStorage.removeItem('sotr-promo');
      localStorage.removeItem('sotr-checkout');
      router.push(`/order/${data.orderId}`);
    } catch (err: any) {
      setServerError(err.message ?? String(err));
    } finally {
      setSubmitting(false);
    }
  };

  const wa = whatsappEnabled();
  const waFallbackLink = wa && form.fullName ? `https://wa.me/${siteConfig.contact.whatsapp}?text=${encodeURIComponent(`Hi Style on the Rocks, I'm placing an order from the site.\nName: ${form.fullName}\nEmail: ${form.email}`)}` : null;

  return (
    <form onSubmit={submit} className="container-x grid gap-10 py-10 md:grid-cols-[1fr_400px]">
      <div>
        <h1 className="h-section mb-6">Checkout</h1>

        <Section title="Contact">
          <Field label="Email" name="email" type="email" value={form.email} onChange={setField} error={errors.email} required />
          <Field label="Phone" name="phone" value={form.phone} onChange={setField} error={errors.phone} />
        </Section>

        <Section title="Delivery">
          <fieldset className="space-y-3">
            <legend className="sr-only">Delivery option</legend>
            {getDeliveryOptions(subtotal, form.province).map((o) => (
              <label key={o.id} className={`flex cursor-pointer items-start gap-3 border p-3 ${form.deliveryOption === o.id ? 'border-ocean bg-ocean/5' : 'border-ink-200'}`}>
                <input type="radio" name="deliveryOption" value={o.id} checked={form.deliveryOption === o.id} onChange={() => setField('deliveryOption', o.id)} className="mt-1" />
                <span className="flex-1">
                  <span className="block text-sm font-medium">{o.label}</span>
                  <span className="block text-xs text-ink-500">{o.description}</span>
                  <span className="block text-xs text-ink-400">{o.etaLabel}</span>
                </span>
                <span className="text-sm">{o.priceCents === 0 ? 'Free' : formatZAR(o.priceCents)}</span>
              </label>
            ))}
          </fieldset>

          {form.deliveryOption !== 'CLICK_COLLECT' ? (
            <>
              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2">
                <Field label="Full name" name="fullName" value={form.fullName} onChange={setField} error={errors.fullName} required />
                <Field label="Address line 1" name="line1" value={form.line1} onChange={setField} error={errors.line1} required />
                <Field label="Address line 2 (optional)" name="line2" value={form.line2} onChange={setField} />
                <Field label="Suburb" name="suburb" value={form.suburb} onChange={setField} />
                <Field label="City" name="city" value={form.city} onChange={setField} error={errors.city} required />
                <SelectField label="Province" name="province" value={form.province} onChange={setField} error={errors.province} required>
                  {SA_PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
                </SelectField>
                <Field label="Postcode" name="postcode" value={form.postcode} onChange={setField} error={errors.postcode} required />
              </div>
            </>
          ) : (
            <p className="mt-3 text-xs text-ink-500">You'll collect from our Umhlanga Rocks boutique — we'll email collection instructions.</p>
          )}
        </Section>

        <Section title="Payment">
          <fieldset className="space-y-3">
            <legend className="sr-only">Payment method</legend>
            <PaymentOption id="PAYFAST" label="PayFast (card or instant EFT)" desc="Secure online payment — PayFast sandbox in dev." checked={form.paymentMethod === 'PAYFAST'} onChange={() => setField('paymentMethod', 'PAYFAST')} />
            <PaymentOption id="EFT" label="Pay by EFT" desc="Bank transfer — order confirmed once proof of payment received." checked={form.paymentMethod === 'EFT'} onChange={() => setField('paymentMethod', 'EFT')} />
            <PaymentOption id="COLLECTION" label="Pay on collection" desc="Pay in store when collecting." checked={form.paymentMethod === 'COLLECTION'} onChange={() => setField('paymentMethod', 'COLLECTION')} />
          </fieldset>
        </Section>

        <Section title="Notes">
          <label className="label" htmlFor="notes">Anything we should know?</label>
          <textarea id="notes" rows={3} value={form.notes} onChange={(e) => setField('notes', e.target.value)} className="input" />
        </Section>

        {serverError ? <p className="mt-4 rounded border border-red-700 bg-red-50 p-3 text-sm text-red-700">{serverError}</p> : null}
      </div>

      <aside className="h-fit border border-ink-200 bg-ivory-100 p-6">
        <h2 className="font-serif text-2xl">Order summary</h2>
        <ul className="mt-4 space-y-3 text-sm">
          {lines.map((l) => (
            <li key={`${l.productId}-${l.size}`} className="flex justify-between gap-3">
              <span>{l.productName} · {l.size} · ×{l.quantity}</span>
              <span>{formatZAR(l.unitPriceCents * l.quantity)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-5 space-y-2 border-t border-ink-200 pt-4 text-sm">
          <Row label="Subtotal" value={formatZAR(subtotal)} />
          <Row label="Shipping" value={shippingCents === 0 ? 'Free' : formatZAR(shippingCents)} />
          {promo.discountCents ? <Row label={`Promo (${promo.code})`} value={`− ${formatZAR(promo.discountCents)}`} /> : null}
          <Row label="VAT (included)" value={formatZAR(totals.vatCents)} />
          <div className="flex justify-between border-t border-ink-200 pt-3 text-base">
            <dt className="font-medium">Total</dt>
            <dd className="font-serif text-xl">{formatZAR(totals.totalCents)}</dd>
          </div>
        </dl>
        <button type="submit" disabled={submitting} className="btn-primary mt-5 w-full">
          {submitting ? 'Placing order…' : form.paymentMethod === 'PAYFAST' ? 'Continue to PayFast' : 'Place order'}
        </button>
        {waFallbackLink ? (
          <a href={waFallbackLink} target="_blank" rel="noopener noreferrer" className="btn-secondary mt-2 w-full">Order on WhatsApp instead</a>
        ) : null}
        <p className="mt-3 text-xs text-ink-500">By placing your order you accept our <a href="/terms" className="underline">terms</a> and acknowledge our <a href="/privacy" className="underline">privacy notice</a>.</p>
      </aside>
    </form>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset className="mb-8">
      <legend className="mb-4 font-serif text-xl">{title}</legend>
      {children}
    </fieldset>
  );
}

function Field({ label, name, value, onChange, type = 'text', required, error }: { label: string; name: keyof FormState; value: string; onChange: <K extends keyof FormState>(k: K, v: FormState[K]) => void; type?: string; required?: boolean; error?: string; }) {
  return (
    <div>
      <label className="label" htmlFor={name}>{label}{required ? ' *' : ''}</label>
      <input id={name} type={type} value={value} onChange={(e) => onChange(name, e.target.value as any)} className="input" required={required} aria-invalid={Boolean(error)} />
      {error ? <p className="mt-1 text-xs text-red-700">{error}</p> : null}
    </div>
  );
}

function SelectField({ label, name, value, onChange, required, error, children }: { label: string; name: keyof FormState; value: string; onChange: <K extends keyof FormState>(k: K, v: FormState[K]) => void; required?: boolean; error?: string; children: React.ReactNode; }) {
  return (
    <div>
      <label className="label" htmlFor={name}>{label}{required ? ' *' : ''}</label>
      <select id={name} value={value} onChange={(e) => onChange(name, e.target.value as any)} className="input" required={required} aria-invalid={Boolean(error)}>
        {children}
      </select>
      {error ? <p className="mt-1 text-xs text-red-700">{error}</p> : null}
    </div>
  );
}

function PaymentOption({ id, label, desc, checked, onChange }: { id: string; label: string; desc: string; checked: boolean; onChange: () => void }) {
  return (
    <label className={`flex cursor-pointer items-start gap-3 border p-3 ${checked ? 'border-ocean bg-ocean/5' : 'border-ink-200'}`}>
      <input type="radio" name="paymentMethod" value={id} checked={checked} onChange={onChange} className="mt-1" />
      <span>
        <span className="block text-sm font-medium">{label}</span>
        <span className="block text-xs text-ink-500">{desc}</span>
      </span>
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between"><dt>{label}</dt><dd>{value}</dd></div>;
}