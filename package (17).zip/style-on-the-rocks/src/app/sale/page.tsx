import { listProducts } from '@/lib/data';
import { ProductCard } from '@/components/product-card';

export const metadata = { title: 'Sale' };

export default async function SalePage() {
  const products = await listProducts({ where: { isOnSale: true }, take: 60 });
  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">Clearance</p>
        <h1 className="h-section mt-2">Sale</h1>
        <p className="mt-2 max-w-prose text-sm text-ink-500">Reduced pieces from past seasons. Final markdowns — while stock lasts.</p>
      </header>
      {products.length === 0 ? (
        <p className="text-sm text-ink-500">No sale items right now.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}