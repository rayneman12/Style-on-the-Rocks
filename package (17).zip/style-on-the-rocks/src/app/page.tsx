import Link from 'next/link';
import { listProducts, listJournalPosts } from '@/lib/data';
import { ProductCard } from '@/components/product-card';
import { siteConfig } from '@config/site.config';

export const revalidate = 60;

export default async function HomePage() {
  const [products, posts] = await Promise.all([
    listProducts({ take: 8, orderBy: { createdAt: 'desc' } }),
    listJournalPosts(),
  ]);
  const newArrivals = await listProducts({ where: { isNew: true }, take: 4, orderBy: { createdAt: 'desc' } });
  return (
    <>
      {/* Hero */}
      <section className="relative isolate">
        <div className="aspect-[16/9] w-full bg-gradient-to-b from-ivory-100 via-ivory-200 to-sand-100">
          <div className="container-x flex h-full flex-col items-start justify-end pb-16 md:pb-24">
            <p className="eyebrow">Umhlanga Rocks · KZN</p>
            <h1 className="h-display mt-3 max-w-3xl text-ink">{siteConfig.brand.tagline}</h1>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link href="/shop/women" className="btn-primary">Shop Women</Link>
              <Link href="/shop/men" className="btn-secondary">Shop Men</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="container-x py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="h-section">Shop the edit</h2>
          <Link href="/shop/women" className="hidden text-sm uppercase tracking-wider2 md:inline">All categories →</Link>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4 md:gap-6">
          {[
            { slug: 'women', label: 'Women' },
            { slug: 'men', label: 'Men' },
            { slug: 'new-arrivals', label: 'New' },
            { slug: 'sale', label: 'Sale' },
          ].map((c) => (
            <Link key={c.slug} href={c.slug === 'new-arrivals' || c.slug === 'sale' ? `/${c.slug}` : `/shop/${c.slug}`} className="group">
              <div className="aspect-[4/5] bg-ivory-200 transition-colors group-hover:bg-ivory-100">
                <div className="flex h-full items-end p-5">
                  <span className="font-serif text-2xl">{c.label}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* New this week */}
      <section className="container-x py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="h-section">New this week</h2>
          <Link href="/new-arrivals" className="text-sm uppercase tracking-wider2">See all →</Link>
        </div>
        <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
          {(newArrivals.length ? newArrivals : products.slice(0, 4)).map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* Personal styling CTA */}
      <section className="bg-ink py-16 text-ivory-50">
        <div className="container-x grid items-center gap-8 md:grid-cols-2">
          <div>
            <p className="eyebrow text-brass-300">Personal styling</p>
            <h2 className="h-section mt-3">A stylist in our boutique, just for you.</h2>
            <p className="mt-4 max-w-prose text-ivory-200">
              Book a 45-minute session with one of our team. We'll prepare pieces based on your size and the occasion.
            </p>
            <Link href="/book-a-stylist" className="btn-secondary mt-6 border-ivory-200 text-ivory-50 hover:bg-ivory-50 hover:text-ink">Book a stylist</Link>
          </div>
          <div className="aspect-[4/5] bg-ocean/40"></div>
        </div>
      </section>

      {/* Journal */}
      {posts.length ? (
        <section className="container-x py-16">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="h-section">From the journal</h2>
            <Link href="/journal" className="text-sm uppercase tracking-wider2">All posts →</Link>
          </div>
          <div className="grid gap-8 md:grid-cols-3">
            {posts.slice(0, 3).map((post) => (
              <Link key={post.id} href={`/journal/${post.slug}`} className="group">
                <div className="aspect-[4/3] overflow-hidden bg-ivory-200">
                  {post.coverImage ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={post.coverImage} alt="" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  ) : null}
                </div>
                <p className="eyebrow mt-3">{post.publishedAt ? new Date(post.publishedAt).toLocaleDateString('en-ZA', { day: '2-digit', month: 'short', year: 'numeric' }) : ''}</p>
                <h3 className="h-card mt-1 group-hover:text-ocean">{post.title}</h3>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </>
  );
}