'use client';
import { useState } from 'react';

export default function BookAStylistPage() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    notes: '',
  });
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error ?? 'Something went wrong. Please try again.');
      }
      setSent(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container-x py-12 md:py-16">
      <div className="grid gap-10 md:grid-cols-[3fr_2fr]">
        <div>
          <p className="eyebrow">Personal styling</p>
          <h1 className="h-section mt-2">Book a stylist</h1>
          <p className="mt-3 max-w-prose text-ink-600">
            A 45-minute session with one of our team. We'll prepare pieces based on your size and the occasion
            — no obligation to buy. Sessions are complimentary.
          </p>

          {sent ? (
            <div className="mt-10 border border-ocean bg-ocean/5 p-6 text-sm">
              <p className="font-medium">Thanks — request received.</p>
              <p className="mt-1 text-ink-600">
                We'll confirm your appointment by email within one business day.
              </p>
            </div>
          ) : (
            <form onSubmit={submit} className="mt-10 space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="label">Name *</label>
                  <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" />
                </div>
                <div>
                  <label className="label">Email *</label>
                  <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input" />
                </div>
                <div>
                  <label className="label">Phone</label>
                  <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" />
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="label">Preferred date *</label>
                  <input type="date" required value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className="input" />
                </div>
                <div>
                  <label className="label">Preferred time *</label>
                  <input type="time" required value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="input" />
                </div>
              </div>
              <div>
                <label className="label">Anything we should know? (occasion, sizes, preferences)</label>
                <textarea rows={4} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="input" />
              </div>
              {error && (
                <p className="text-sm text-red-600" role="alert">{error}</p>
              )}
              <button type="submit" className="btn-primary disabled:opacity-60" disabled={submitting}>
                {submitting ? 'Sending…' : 'Request appointment'}
              </button>
            </form>
          )}
        </div>

        <aside className="h-fit border border-ink-200 bg-ivory-100 p-6 text-sm">
          <p className="eyebrow">What to expect</p>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-ink-600">
            <li>45 minutes, in our Umhlanga Rocks boutique</li>
            <li>Pieces prepared ahead of time based on your size</li>
            <li>Honest, no-pressure advice</li>
            <li>Complimentary tea, coffee, or something stronger</li>
          </ul>
          <p className="eyebrow mt-6">Group bookings</p>
          <p className="mt-2 text-ink-600">
            For groups of three or more, contact us directly and we'll arrange a private session.
          </p>
        </aside>
      </div>
    </div>
  );
}
