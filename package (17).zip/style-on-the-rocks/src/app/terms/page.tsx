export const metadata = { title: 'Terms' };

export default function TermsPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Legal</p>
      <h1 className="h-section mt-2">Terms of sale</h1>
      <p className="mt-3 text-sm text-ink-500">Last updated: this build.</p>

      <h2 className="font-serif text-2xl mt-10">Pricing &amp; availability</h2>
      <p className="mt-2 text-ink-700">
        All prices are VAT-inclusive. We try to keep stock levels accurate, but in rare cases an item may
        become unavailable between order placement and packing. We'll refund or offer an alternative.
      </p>

      <h2 className="font-serif text-2xl mt-8">Payment</h2>
      <p className="mt-2 text-ink-700">
        We accept PayFast (cards and instant EFT), EFT, and pay-on-collection. Orders paid by EFT are
        confirmed once payment reflects in our account.
      </p>

      <h2 className="font-serif text-2xl mt-8">Delivery</h2>
      <p className="mt-2 text-ink-700">
        Risk in the goods passes to you on delivery. See our <a href="/delivery" className="underline">Delivery</a> page
        for current rates and ETAs.
      </p>

      <h2 className="font-serif text-2xl mt-8">Returns</h2>
      <p className="mt-2 text-ink-700">
        See our <a href="/returns" className="underline">Returns &amp; refunds</a> page.
      </p>

      <h2 className="font-serif text-2xl mt-8">Warranty</h2>
      <p className="mt-2 text-ink-700">
        All goods carry the warranty implied by the Consumer Protection Act. If something is defective,
        we'll repair, replace, or refund.
      </p>

      <h2 className="font-serif text-2xl mt-8">Governing law</h2>
      <p className="mt-2 text-ink-700">
        These terms are governed by the laws of the Republic of South Africa.
      </p>
    </div>
  );
}
