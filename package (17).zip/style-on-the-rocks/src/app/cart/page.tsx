'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/stores/cart';
import { formatZAR } from '@/lib/pricing';
import { PromoInput } from '@/components/promo-input';

export default function CartPage() {
  const lines = useCart((s) => s.lines);
  const update = useCart((s) => s.update);
  const remove = useCart((s) => s.remove);
  const clear = useCart((s) => s.clear);
  const subtotal = useCart((s) => s.lines.reduce((a, l) => a + l.unitPriceCents * l.quantity, 0));
  const [submitting, setSubmitting] = useState(false);

  if (lines.length === 0) {
    return (
      <div className="container-x py-16 text-center">
        <h1 className="h-section">Your bag is empty</h1>
        <p className="mt-2 text-sm text-ink-500">Browse the new arrivals or shop by category.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <Link href="/shop/women" className="btn-primary">Shop Women</Link>
          <Link href="/shop/men" className="btn-secondary">Shop Men</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container-x grid gap-10 py-10 md:grid-cols-[1fr_360px]">
      <div>
        <h1 className="h-section mb-6">Your bag</h1>
        <ul className="divide-y divide-ink-200 border-y border-ink-200">
          {lines.map((l) => (
            <li key={`${l.productId}-${l.size}`} className="flex gap-4 py-5">
              <div className="h-24 w-20 flex-none overflow-hidden bg-ivory-200">
                {l.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={l.image} alt="" className="h-full w-full object-cover" />
                ) : null}
              </div>
              <div className="flex-1 text-sm">
                <Link href={`/product/${l.productSlug}`} className="font-serif text-lg">{l.productName}</Link>
                <p className="mt-1 text-ink-500">Size {l.size}</p>
                <div className="mt-3 flex items-center gap-2">
                  <button onClick={() => update(l.productId, l.size, l.quantity - 1)} aria-label="Decrease" className="h-8 w-8 border border-ink-200">−</button>
                  <span className="w-8 text-center">{l.quantity}</span>
                  <button onClick={() => update(l.productId, l.size, l.quantity + 1)} aria-label="Increase" className="h-8 w-8 border border-ink-200">+</button>
                  <button onClick={() => remove(l.productId, l.size)} className="ml-3 text-xs uppercase tracking-wider2 text-ink-500 underline-offset-4 hover:underline">Remove</button>
                </div>
              </div>
              <div className="text-right text-sm">{formatZAR(l.unitPriceCents * l.quantity)}</div>
            </li>
          ))}
        </ul>
        <button onClick={clear} className="mt-4 text-xs uppercase tracking-wider2 text-ink-500 underline-offset-4 hover:underline">Clear bag</button>
      </div>

      <aside className="h-fit border border-ink-200 bg-ivory-100 p-6">
        <h2 className="font-serif text-2xl">Summary</h2>
        <PromoInput />
        <dl className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between"><dt>Subtotal</dt><dd>{formatZAR(subtotal)}</dd></div>
          <p className="text-xs text-ink-500">VAT included. Shipping &amp; any promo discount calculated at checkout.</p>
        </dl>
        <Link href="/checkout" className="btn-primary mt-5 w-full">Checkout</Link>
        <Link href="/shop" className="btn-ghost mt-2 w-full">Continue shopping</Link>
      </aside>
    </div>
  );
}