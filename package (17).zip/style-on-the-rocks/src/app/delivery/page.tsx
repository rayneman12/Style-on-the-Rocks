export const metadata = { title: 'Delivery' };

export default function DeliveryPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Help</p>
      <h1 className="h-section mt-2">Delivery</h1>

      <h2 className="font-serif text-2xl mt-10">Click & Collect — free</h2>
      <p className="mt-2 text-ink-700">
        Collect from our Umhlanga Rocks boutique. Ready within 1 business day. We'll email when your order is packed.
      </p>

      <h2 className="font-serif text-2xl mt-8">Local delivery (Umhlanga / greater Durban)</h2>
      <p className="mt-2 text-ink-700">
        Hand-delivered within the Umhlanga and greater Durban area, 1–2 business days.
        R 80; free on orders over R 1 500.
      </p>

      <h2 className="font-serif text-2xl mt-8">Courier — nationwide</h2>
      <p className="mt-2 text-ink-700">
        Door-to-door courier with tracking. Rates depend on province, free on orders over R 1 500.
        Standard ETAs are 2–5 business days depending on region.
      </p>
      <table className="mt-4 w-full text-sm">
        <thead className="text-ink-500">
          <tr><th className="py-1 text-left">Region</th><th className="py-1 text-left">ETA</th><th className="py-1 text-right">Rate</th></tr>
        </thead>
        <tbody>
          <tr><td>Gauteng</td><td>2–4 business days</td><td className="text-right">R 160</td></tr>
          <tr><td>KwaZulu-Natal</td><td>1–3 business days</td><td className="text-right">R 120</td></tr>
          <tr><td>Eastern Cape</td><td>3–5 business days</td><td className="text-right">R 180</td></tr>
          <tr><td>Western Cape</td><td>3–5 business days</td><td className="text-right">R 180</td></tr>
          <tr><td>Free State</td><td>3–5 business days</td><td className="text-right">R 180</td></tr>
          <tr><td>Limpopo / Mpumalanga</td><td>3–5 business days</td><td className="text-right">R 200</td></tr>
          <tr><td>Northern Cape / North West</td><td>3–6 business days</td><td className="text-right">R 200 / R 180</td></tr>
        </tbody>
      </table>

      <h2 className="font-serif text-2xl mt-10">Tracking</h2>
      <p className="mt-2 text-ink-700">
        Once your order is collected by the courier, you'll receive a tracking link by email.
        Local and click &amp; collect orders don't carry tracking but you'll be notified when they're out for delivery or ready.
      </p>
    </div>
  );
}
