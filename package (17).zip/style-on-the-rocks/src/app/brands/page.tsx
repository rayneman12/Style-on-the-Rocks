import Link from 'next/link';
import { listBrands } from '@/lib/data';

export const metadata = { title: 'Brands' };

export default async function BrandsPage() {
  const brands = await listBrands();
  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">House of</p>
        <h1 className="h-section mt-2">Brands</h1>
        <p className="mt-2 max-w-prose text-sm text-ink-500">The labels we currently stock. The boutique owner can edit this list via the admin panel.</p>
      </header>
      {brands.length === 0 ? (
        <p className="text-sm text-ink-500">No brands added yet.</p>
      ) : (
        <ul className="grid gap-6 md:grid-cols-3">
          {brands.map((b) => (
            <li key={b.id} className="border border-ink-200 p-5">
              <Link href={`/brands/${b.slug}`} className="font-serif text-xl hover:text-ocean">{b.name}</Link>
              {b.bio ? <p className="mt-2 text-xs text-ink-500">{b.bio}</p> : null}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}