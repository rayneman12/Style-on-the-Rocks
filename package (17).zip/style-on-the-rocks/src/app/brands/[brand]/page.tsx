import { notFound } from 'next/navigation';
import { listBrands, listProducts } from '@/lib/data';
import { ProductCard } from '@/components/product-card';

export async function generateStaticParams() {
  const brands = await listBrands();
  return brands.map((b) => ({ brand: b.slug }));
}

export async function generateMetadata({ params }: { params: { brand: string } }) {
  return { title: params.brand };
}

export default async function BrandPage({ params }: { params: { brand: string } }) {
  const brands = await listBrands();
  const brand = brands.find((b) => b.slug === params.brand);
  if (!brand) notFound();
  const products = await listProducts({ where: { brand: { slug: params.brand } } });
  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">Brand</p>
        <h1 className="h-section mt-2">{brand.name}</h1>
        {brand.bio ? <p className="mt-2 max-w-prose text-sm text-ink-500">{brand.bio}</p> : null}
      </header>
      {products.length === 0 ? (
        <p className="text-sm text-ink-500">No products from this brand yet.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}