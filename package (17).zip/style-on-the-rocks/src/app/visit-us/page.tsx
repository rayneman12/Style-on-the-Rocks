import { siteConfig } from '@config/site.config';

export const metadata = { title: 'Visit us' };

export default function VisitUsPage() {
  const lat = siteConfig.location.mapLat;
  const lng = siteConfig.location.mapLng;
  const zoom = siteConfig.location.mapZoom;
  // OpenStreetMap embed (no API key needed) — graceful fallback if address is null.
  const src = `https://www.openstreetmap.org/export/embed.html?bbox=${lng - 0.01}%2C${lat - 0.01}%2C${lng + 0.01}%2C${lat + 0.01}&layer=mapnik&marker=${lat}%2C${lng}`;
  return (
    <div className="container-x py-12 md:py-16">
      <p className="eyebrow">Visit us</p>
      <h1 className="h-section mt-2">{siteConfig.location.boutique}</h1>
      <p className="mt-3 max-w-prose text-ink-600">
        Pop in to browse the edit, try pieces on, and chat to our team. We keep our full size run in the boutique —
        if we don't have what you're looking for, we'll do our best to source it.
      </p>

      <div className="mt-10 grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="font-serif text-2xl">Address</h2>
          <address className="not-italic text-sm text-ink-600">
            {siteConfig.location.addressLine1 ?? 'Address line 1 — populate in config/site.config.ts'}<br />
            {siteConfig.location.addressLine2 ? <>{siteConfig.location.addressLine2}<br /></> : null}
            {siteConfig.location.suburb ? <>{siteConfig.location.suburb}<br /></> : null}
            {siteConfig.location.city}, {siteConfig.location.province} {siteConfig.location.postcode ?? ''}<br />
            {siteConfig.location.country}
          </address>
          <p className="mt-3 text-xs text-ink-500">
            (Owner hasn't supplied the street address yet — placeholder shown on map.)
          </p>

          <h2 className="mt-8 font-serif text-2xl">Hours</h2>
          <table className="mt-3 text-sm">
            <tbody>
              {siteConfig.hours.weekly.map(([day, open, close]) => (
                <tr key={day}>
                  <td className="pr-6 py-1 text-ink-500">{day}</td>
                  <td className="py-1">{open && close ? `${open} — ${close}` : <span className="text-ink-400">Closed</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {siteConfig.hours.publicNote ? (
            <p className="mt-3 text-xs text-ink-500">{siteConfig.hours.publicNote}</p>
          ) : null}
        </div>

        <div className="aspect-[4/3] w-full overflow-hidden border border-ink-200 bg-ivory-200">
          <iframe
            title="Boutique map"
            src={src}
            className="h-full w-full"
            loading="lazy"
            style={{ border: 0 }}
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </div>
  );
}
