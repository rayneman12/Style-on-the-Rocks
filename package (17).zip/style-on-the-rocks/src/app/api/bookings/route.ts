import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/email';
import { auth } from '@/lib/auth';

const Body = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional().nullable(),
  date: z.string().min(1), // yyyy-mm-dd
  time: z.string().min(1), // HH:mm
  notes: z.string().optional().nullable(),
});

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = Body.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }
  const input = parsed.data;

  const startsAt = new Date(`${input.date}T${input.time}:00`);
  if (Number.isNaN(startsAt.getTime())) {
    return NextResponse.json({ error: 'Invalid date or time.' }, { status: 400 });
  }
  if (startsAt.getTime() < Date.now()) {
    return NextResponse.json({ error: 'Please choose a future date and time.' }, { status: 400 });
  }

  const session = await auth().catch(() => null);
  const userId = (session?.user as any)?.id ?? null;

  const booking = await prisma.stylistBooking.create({
    data: {
      userId,
      name: input.name,
      email: input.email,
      phone: input.phone ?? null,
      startsAt,
      notes: input.notes ?? null,
      status: 'REQUESTED',
    },
  });

  await sendEmail({
    to: input.email,
    subject: 'Your styling session request — Style on the Rocks',
    html: `<p>Hi ${input.name},</p><p>We've received your request for a styling session on ${startsAt.toLocaleString('en-ZA')}. We'll confirm by email within one business day.</p>`,
    text: `Hi ${input.name}, we've received your request for a styling session on ${startsAt.toLocaleString('en-ZA')}. We'll confirm by email within one business day.`,
  }).catch(() => null);

  return NextResponse.json({ ok: true, bookingId: booking.id });
}
