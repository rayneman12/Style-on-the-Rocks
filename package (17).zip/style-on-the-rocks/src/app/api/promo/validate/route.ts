import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { evaluatePromo } from '@/lib/promo';

export async function POST(req: NextRequest) {
  const { code, subtotalCents } = await req.json();
  if (!code || typeof subtotalCents !== 'number') {
    return NextResponse.json({ ok: false, reason: 'Missing code or amount.' }, { status: 400 });
  }
  const promo = await prisma.promoCode.findUnique({ where: { code: String(code).trim().toUpperCase() } });
  if (!promo) return NextResponse.json({ ok: false, reason: 'Code not recognised.' });
  const result = evaluatePromo(
    {
      code: promo.code,
      type: promo.type as 'PERCENT' | 'FIXED',
      value: promo.value,
      minSubtotalCents: promo.minSubtotalCents,
      active: promo.active,
      startsAt: promo.startsAt,
      endsAt: promo.endsAt,
      usageLimit: promo.usageLimit,
      usedCount: promo.usedCount,
    },
    subtotalCents,
  );
  if (!result.ok) return NextResponse.json({ ok: false, reason: result.reason });
  return NextResponse.json({ ok: true, discountCents: result.discountCents, code: promo.code });
}