import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'crypto';
import { prisma } from '@/lib/prisma';
import { computeTotals } from '@/lib/pricing';
import { getShippingCost, isValidPostcode, SA_PROVINCES } from '@/lib/shipping';
import { evaluatePromo } from '@/lib/promo';
import { buildCheckoutUrl } from '@/lib/payfast';
import { sendEmail } from '@/lib/email';
import { siteConfig, whatsappEnabled } from '@config/site.config';
import { newId } from '@/lib/id';

const Body = z.object({
  email: z.string().email(),
  fullName: z.string().min(1),
  phone: z.string().optional().nullable(),
  line1: z.string().optional().nullable(),
  line2: z.string().optional().nullable(),
  suburb: z.string().optional().nullable(),
  city: z.string().optional().nullable(),
  province: z.string().optional().nullable(),
  postcode: z.string().optional().nullable(),
  deliveryOption: z.enum(['CLICK_COLLECT', 'LOCAL', 'COURIER']),
  paymentMethod: z.enum(['PAYFAST', 'EFT', 'COLLECTION']),
  notes: z.string().optional().nullable(),
  items: z.array(z.object({
    productId: z.string(),
    productSlug: z.string(),
    productName: z.string(),
    size: z.string(),
    unitPriceCents: z.number(),
    quantity: z.number().int().min(1),
  })).min(1),
  promoCode: z.string().nullable().optional(),
});

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = Body.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid input', details: parsed.error.flatten() }, { status: 400 });
  }
  const input = parsed.data;

  // Validate address when not click-collect.
  if (input.deliveryOption !== 'CLICK_COLLECT') {
    if (!input.line1) return NextResponse.json({ error: 'Address line 1 is required.' }, { status: 400 });
    if (!input.city) return NextResponse.json({ error: 'City is required.' }, { status: 400 });
    if (!SA_PROVINCES.includes(input.province as any)) return NextResponse.json({ error: 'Invalid province.' }, { status: 400 });
    if (!input.postcode || !isValidPostcode(input.postcode)) {
      return NextResponse.json({ error: 'Invalid postcode — South African postcodes are 4 digits.' }, { status: 400 });
    }
  }

  // Idempotency — derive a deterministic id from cart + email + amount.
  // (For real systems, use a request id header.)
  const idempotencyKey = crypto
    .createHash('sha256')
    .update(JSON.stringify({ email: input.email, items: input.items }))
    .digest('hex')
    .slice(0, 32);

  // If we've already created an order for this idempotency key, return it.
  const existing = await prisma.order.findUnique({ where: { idempotencyKey } });
  if (existing) {
    let paymentUrl: string | null = null;
    if (existing.paymentMethod === 'PAYFAST') {
      const base = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';
      paymentUrl = buildCheckoutUrl(
        {
          m_payment_id: existing.id,
          amount: existing.totalCents / 100,
          item_name: `Order ${existing.number}`,
          email_address: existing.email,
          return_url: `${base}/order/${existing.id}`,
          cancel_url: `${base}/cart`,
          notify_url: `${base}/api/payfast/notify`,
        },
        base,
      );
    }
    return NextResponse.json({
      orderId: existing.id,
      orderNumber: existing.number,
      paymentMethod: existing.paymentMethod,
      paymentUrl,
      whatsappFallback: whatsappEnabled() ? `https://wa.me/${siteConfig.contact.whatsapp}` : null,
      deduped: true,
    });
  }

  // Server-side recompute prices — never trust client.
  const ids = input.items.map((i) => i.productId);
  const products = await prisma.product.findMany({ where: { id: { in: ids } }, include: { variants: true } });
  const productById = new Map(products.map((p) => [p.id, p]));

  let subtotalCents = 0;
  const itemsForOrder: Array<{ productId: string; productSlug: string; productName: string; size: string; color?: string | null; unitPriceCents: number; quantity: number; variantId: string; }> = [];

  for (const line of input.items) {
    const p = productById.get(line.productId);
    if (!p) return NextResponse.json({ error: `Unknown product: ${line.productId}` }, { status: 400 });
    if (p.status !== 'ACTIVE') return NextResponse.json({ error: `${p.name} is not available.` }, { status: 400 });
    const variant = p.variants.find((v) => v.size === line.size);
    if (!variant) return NextResponse.json({ error: `${p.name} (size ${line.size}) not available.` }, { status: 400 });
    if (variant.stock < line.quantity) return NextResponse.json({ error: `${p.name} size ${line.size} only has ${variant.stock} in stock.` }, { status: 400 });
    subtotalCents += p.priceCents * line.quantity;
    itemsForOrder.push({
      productId: p.id,
      productSlug: p.slug,
      productName: p.name,
      size: line.size,
      color: variant.color ?? null,
      unitPriceCents: p.priceCents,
      quantity: line.quantity,
      variantId: variant.id,
    });
  }

  const shippingCents = getShippingCost(input.deliveryOption, subtotalCents, input.province ?? 'KwaZulu-Natal');

  let discountCents = 0;
  let promoId: string | null = null;
  if (input.promoCode) {
    const promo = await prisma.promoCode.findUnique({ where: { code: input.promoCode } });
    if (promo) {
      const r = evaluatePromo(
        {
          code: promo.code,
          type: promo.type as 'PERCENT' | 'FIXED',
          value: promo.value,
          minSubtotalCents: promo.minSubtotalCents,
          active: promo.active,
          startsAt: promo.startsAt,
          endsAt: promo.endsAt,
          usageLimit: promo.usageLimit,
          usedCount: promo.usedCount,
        },
        subtotalCents,
      );
      if (r.ok) {
        discountCents = r.discountCents;
        promoId = promo.id;
      }
    }
  }

  const totals = computeTotals({ subtotalCents, shippingCents, discountCents });
  const totalCents = totals.totalCents;

  // PayFast requires the amount in RANDS with 2 decimals. Convert from cents.
  const payfastAmount = (totalCents / 100).toFixed(2);

  const orderNumber = `SOR-${Date.now().toString(36).toUpperCase()}`;
  const order = await prisma.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        number: orderNumber,
        email: input.email.toLowerCase(),
        status: input.paymentMethod === 'PAYFAST' ? 'PENDING_PAYMENT' : 'PENDING_PAYMENT',
        paymentMethod: input.paymentMethod,
        subtotalCents,
        shippingCents,
        discountCents,
        vatCents: totals.vatCents,
        totalCents,
        promoCode: input.promoCode ?? null,
        shippingName: input.fullName,
        shippingLine1: input.line1 ?? '',
        shippingLine2: input.line2 ?? null,
        shippingSuburb: input.suburb ?? null,
        shippingCity: input.city ?? 'Umhlanga Rocks',
        shippingProvince: input.province ?? 'KwaZulu-Natal',
        shippingPostcode: input.postcode ?? '',
        shippingCountry: 'South Africa',
        shippingPhone: input.phone ?? null,
        deliveryOption: input.deliveryOption,
        idempotencyKey,
        items: {
          create: itemsForOrder.map((i) => ({
            productId: i.productId,
            productName: i.productName,
            productSlug: i.productSlug,
            size: i.size,
            color: i.color,
            quantity: i.quantity,
            unitPriceCents: i.unitPriceCents,
          })),
        },
        statusEvents: { create: { status: 'PENDING_PAYMENT', note: 'Order created' } },
      },
    });
    if (promoId) await tx.promoCode.update({ where: { id: promoId }, data: { usedCount: { increment: 1 } } });
    return created;
  });

  // Email confirmation (logged to console + persisted for /admin/emails preview).
  await sendEmail({
    to: input.email,
    subject: `Your Style on the Rocks order ${order.number}`,
    html: renderOrderEmail(order, itemsForOrder),
  });

  let paymentUrl: string | null = null;
  if (input.paymentMethod === 'PAYFAST') {
    const base = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';
    paymentUrl = buildCheckoutUrl(
      {
        m_payment_id: order.id,
        amount: Number(payfastAmount),
        item_name: `Order ${order.number}`,
        email_address: input.email,
        return_url: `${base}/order/${order.id}`,
        cancel_url: `${base}/cart`,
        notify_url: `${base}/api/payfast/notify`,
      },
      base,
    );
  }

  return NextResponse.json({
    orderId: order.id,
    orderNumber: order.number,
    paymentMethod: input.paymentMethod,
    paymentUrl,
    whatsappFallback: whatsappEnabled() ? `https://wa.me/${siteConfig.contact.whatsapp}` : null,
  });
}

function renderOrderEmail(order: { number: string; totalCents: number; subtotalCents: number; shippingCents: number; discountCents: number; deliveryOption: string; paymentMethod: string }, items: Array<{ productName: string; size: string; quantity: number; unitPriceCents: number }>): string {
  const rands = (n: number) => `R ${(n / 100).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ')}`;
  return `
    <div style="font-family: Georgia, serif; max-width: 560px; margin: 0 auto;">
      <h1 style="font-size: 28px; margin-bottom: 4px;">Thank you</h1>
      <p style="color: #555;">Your order <strong>${order.number}</strong> is confirmed.</p>
      <table style="width: 100%; margin-top: 16px; border-collapse: collapse;">
        ${items.map((i) => `<tr><td style="padding: 6px 0; border-bottom: 1px solid #eee;">${i.productName} · ${i.size} · ×${i.quantity}</td><td align="right" style="padding: 6px 0; border-bottom: 1px solid #eee;">${rands(i.unitPriceCents * i.quantity)}</td></tr>`).join('')}
      </table>
      <table style="width: 100%; margin-top: 12px;">
        <tr><td>Subtotal</td><td align="right">${rands(order.subtotalCents)}</td></tr>
        <tr><td>Shipping</td><td align="right">${order.shippingCents === 0 ? 'Free' : rands(order.shippingCents)}</td></tr>
        ${order.discountCents ? `<tr><td>Discount</td><td align="right">− ${rands(order.discountCents)}</td></tr>` : ''}
        <tr><td style="padding-top: 8px;"><strong>Total</strong></td><td align="right" style="padding-top: 8px;"><strong>${rands(order.totalCents)}</strong></td></tr>
      </table>
      <p style="margin-top: 16px; color: #555;">Delivery option: ${order.deliveryOption}</p>
      <p style="color: #555;">Payment: ${order.paymentMethod}</p>
      <p style="margin-top: 24px; color: #777; font-size: 12px;">Style on the Rocks · Umhlanga Rocks, KZN</p>
    </div>
  `;
}