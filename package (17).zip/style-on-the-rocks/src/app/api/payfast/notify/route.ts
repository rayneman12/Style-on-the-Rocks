/**
 * PayFast Instant Transaction Notification (ITN) handler.
 *
 * PayFast server-to-server callback that marks an order as PAID.
 * Always responds 200 OK so PayFast stops retrying; we record
 * invalid/duplicate payloads in EmailLog/console for ops to inspect.
 */
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyItn } from '@/lib/payfast';
import { sendEmail } from '@/lib/email';

export async function POST(req: NextRequest) {
  // PayFast posts application/x-www-form-urlencoded
  const form = await req.formData();
  const payload: Record<string, string> = {};
  for (const [k, v] of form.entries()) payload[k] = String(v);

  const v = await verifyItn(payload);
  if (!v.valid) {
    console.warn('[payfast/notify] invalid ITN', v.reasons, payload);
    return NextResponse.json({ ok: false, reasons: v.reasons }, { status: 200 });
  }

  const m_payment_id = String(payload.m_payment_id ?? '');
  const status = String(payload.payment_status ?? '').toUpperCase();
  const pfPaymentId = String(payload.pf_payment_id ?? '');

  const order = await prisma.order.findUnique({ where: { id: m_payment_id } });
  if (!order) {
    console.warn('[payfast/notify] order not found', m_payment_id);
    return NextResponse.json({ ok: false, reason: 'unknown order' }, { status: 200 });
  }

  // Idempotency — if already paid, no-op.
  if (order.status === 'PAID') {
    return NextResponse.json({ ok: true, alreadyPaid: true });
  }

  if (status === 'COMPLETE') {
    await prisma.$transaction(async (tx) => {
      await tx.order.update({
        where: { id: order.id },
        data: {
          status: 'PAID',
          paymentRef: pfPaymentId || null,
          paidAt: new Date(),
          statusEvents: { create: { status: 'PAID', note: `PayFast ${pfPaymentId}` } },
        },
      });
      // Decrement stock now that payment has settled.
      const items = await tx.orderItem.findMany({ where: { orderId: order.id } });
      for (const it of items) {
        const v = await tx.productVariant.findFirst({
          where: { productId: it.productId, size: it.size, color: it.color ?? undefined },
        });
        if (v) {
          await tx.productVariant.update({
            where: { id: v.id },
            data: { stock: Math.max(0, v.stock - it.quantity) },
          });
        }
      }
    });

    // Customer paid confirmation
    await sendEmail({
      to: order.email,
      subject: `Payment received — order ${order.number}`,
      html: `<div style="font-family: Georgia, serif; max-width: 560px; margin: 0 auto;">
        <h1 style="font-size: 24px; margin-bottom: 4px;">Thank you</h1>
        <p style="color: #555;">We've received your payment for order <strong>${order.number}</strong>.</p>
        <p style="color: #555;">We'll be in touch with shipping / collection details.</p>
        <p style="margin-top: 24px; color: #777; font-size: 12px;">Style on the Rocks · Umhlanga Rocks, KZN</p>
      </div>`,
    });

    return NextResponse.json({ ok: true, paid: true });
  }

  // Pending / failed / cancelled — leave order in PENDING_PAYMENT.
  await prisma.order.update({
    where: { id: order.id },
    data: { statusEvents: { create: { status: order.status, note: `PayFast ${status}` } } },
  });
  return NextResponse.json({ ok: true, ignored: status });
}
