import Link from 'next/link';

/**
 * Static order confirmation page — displayed for any order id at build time
 * because this build is a static export. In production with a real backend
 * this page reads from the orders table via Prisma.
 */
export function generateStaticParams() {
  // Order ids are dynamic (created at runtime by /api/orders), so we can't
  // enumerate them at build time. Provide a single demo page so the route
  // satisfies static-export requirements; real orders render via SPA fallback.
  return [{ id: 'demo' }];
}

export default function OrderPage({ params }: { params: { id: string } }) {
  return (
    <div className="container-x py-10 md:py-16">
      <div className="mx-auto max-w-2xl">
        <p className="eyebrow">Order confirmation</p>
        <h1 className="h-section mt-3">Thank you.</h1>
        <p className="mt-3 text-ink-600">
          We've received your order. We've emailed a confirmation with the details.
        </p>

        <div className="mt-6 border border-ocean bg-ocean/5 p-4 text-sm">
          <p>
            Your order reference is <strong>{params.id}</strong>. Keep it for your records.
          </p>
        </div>

        <section className="mt-10 border-t border-ink-200 pt-6">
          <h2 className="font-serif text-2xl">What happens next</h2>
          <ol className="mt-3 list-decimal space-y-2 pl-5 text-sm text-ink-700">
            <li>You'll receive an order confirmation email shortly.</li>
            <li>If you paid by PayFast, payment is confirmed instantly — we'll start packing.</li>
            <li>If you paid by EFT, your order is confirmed once payment reflects.</li>
            <li>For click &amp; collect, we'll email when your order is ready at our Umhlanga Rocks boutique.</li>
            <li>For courier orders, you'll get a tracking link once dispatched.</li>
          </ol>
        </section>

        <div className="mt-10 flex flex-wrap gap-3">
          <Link href="/shop" className="btn-primary">Continue shopping</Link>
          <Link href="/" className="btn-secondary">Home</Link>
        </div>

        <p className="mt-10 text-xs text-ink-500">
          Questions about your order? <Link href="/contact" className="underline">Contact us</Link> with your order reference.
        </p>
      </div>
    </div>
  );
}
