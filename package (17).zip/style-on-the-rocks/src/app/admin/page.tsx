import Link from 'next/link';
import { redirect } from 'next/navigation';
import { auth } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export const metadata = { title: 'Admin' };

function rand(cents: number) {
  return `R ${(cents / 100).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;
}

export default async function AdminPage() {
  const session = await auth();
  const role = (session?.user as any)?.role;

  if (!session) {
    redirect('/login?callbackUrl=/admin');
  }
  if (role !== 'ADMIN') {
    return (
      <div className="container-x py-16">
        <h1 className="h-section">Not authorised</h1>
        <p className="mt-3 text-ink-600">This area is for boutique staff only.</p>
      </div>
    );
  }

  const [orders, lowStockVariants, pendingBookings, orderStats] = await Promise.all([
    prisma.order.findMany({
      orderBy: { createdAt: 'desc' },
      take: 20,
      include: { items: true },
    }),
    prisma.productVariant.findMany({
      where: { stock: { lte: 3 } },
      orderBy: { stock: 'asc' },
      take: 20,
      include: { product: { select: { name: true, slug: true } } },
    }),
    prisma.stylistBooking.findMany({
      where: { status: 'REQUESTED' },
      orderBy: { startsAt: 'asc' },
      take: 10,
    }),
    prisma.order.aggregate({
      _sum: { totalCents: true },
      _count: true,
      where: { status: { in: ['PAID', 'PACKED', 'SHIPPED', 'COLLECTED'] } },
    }),
  ]);

  return (
    <div className="container-x py-12 md:py-16">
      <p className="eyebrow">Boutique admin</p>
      <h1 className="h-section mt-2">Dashboard</h1>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="border border-ink-200 bg-ivory-100 p-6">
          <p className="text-sm text-ink-500">Paid orders</p>
          <p className="mt-1 font-serif text-3xl">{orderStats._count}</p>
        </div>
        <div className="border border-ink-200 bg-ivory-100 p-6">
          <p className="text-sm text-ink-500">Revenue (paid+)</p>
          <p className="mt-1 font-serif text-3xl">{rand(orderStats._sum.totalCents ?? 0)}</p>
        </div>
        <div className="border border-ink-200 bg-ivory-100 p-6">
          <p className="text-sm text-ink-500">Low / sold-out variants</p>
          <p className="mt-1 font-serif text-3xl">{lowStockVariants.length}</p>
        </div>
      </div>

      <section className="mt-12">
        <h2 className="font-serif text-2xl">Recent orders</h2>
        <div className="mt-4 overflow-x-auto border border-ink-200">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-ivory-100 text-left">
              <tr>
                <th className="px-4 py-3">Order</th>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Payment</th>
                <th className="px-4 py-3">Total</th>
                <th className="px-4 py-3">Placed</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-t border-ink-100">
                  <td className="px-4 py-3">
                    <Link href={`/order/${o.id}`} className="underline">{o.number}</Link>
                  </td>
                  <td className="px-4 py-3">{o.email}</td>
                  <td className="px-4 py-3">{o.status}</td>
                  <td className="px-4 py-3">{o.paymentMethod}</td>
                  <td className="px-4 py-3">{rand(o.totalCents)}</td>
                  <td className="px-4 py-3">{o.createdAt.toLocaleDateString('en-ZA')}</td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-ink-500">No orders yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-12">
        <h2 className="font-serif text-2xl">Low stock</h2>
        <div className="mt-4 overflow-x-auto border border-ink-200">
          <table className="w-full min-w-[480px] text-sm">
            <thead className="bg-ivory-100 text-left">
              <tr>
                <th className="px-4 py-3">Product</th>
                <th className="px-4 py-3">Size / colour</th>
                <th className="px-4 py-3">Stock</th>
              </tr>
            </thead>
            <tbody>
              {lowStockVariants.map((v) => (
                <tr key={v.id} className="border-t border-ink-100">
                  <td className="px-4 py-3">
                    <Link href={`/product/${v.product.slug}`} className="underline">{v.product.name}</Link>
                  </td>
                  <td className="px-4 py-3">{v.size}{v.color ? ` · ${v.color}` : ''}</td>
                  <td className="px-4 py-3">{v.stock <= 0 ? <span className="text-red-600">Sold out</span> : v.stock}</td>
                </tr>
              ))}
              {lowStockVariants.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-4 py-6 text-center text-ink-500">Everything's well stocked.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="mt-12">
        <h2 className="font-serif text-2xl">Pending stylist bookings</h2>
        <div className="mt-4 overflow-x-auto border border-ink-200">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-ivory-100 text-left">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Requested time</th>
                <th className="px-4 py-3">Notes</th>
              </tr>
            </thead>
            <tbody>
              {pendingBookings.map((b) => (
                <tr key={b.id} className="border-t border-ink-100">
                  <td className="px-4 py-3">{b.name}</td>
                  <td className="px-4 py-3">{b.email}</td>
                  <td className="px-4 py-3">{b.startsAt.toLocaleString('en-ZA')}</td>
                  <td className="px-4 py-3">{b.notes ?? '—'}</td>
                </tr>
              ))}
              {pendingBookings.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-ink-500">No pending requests.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <p className="mt-10 text-xs text-ink-500">
        Order status changes, product editing, and confirming bookings still need to be wired up — this view is read-only for now.
      </p>
    </div>
  );
}
