export const metadata = { title: 'Cookies' };

export default function CookiesPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Legal</p>
      <h1 className="h-section mt-2">Cookies notice</h1>

      <h2 className="font-serif text-2xl mt-10">What we use</h2>
      <ul className="mt-3 list-disc space-y-1 pl-5 text-ink-700">
        <li><strong>Strictly necessary</strong> — session ID, cart contents, authentication.</li>
        <li><strong>Preferences</strong> — promo code applied, recently-viewed items.</li>
        <li><strong>Analytics</strong> — anonymous page views. No advertising trackers.</li>
      </ul>

      <h2 className="font-serif text-2xl mt-8">Controlling cookies</h2>
      <p className="mt-2 text-ink-700">
        You can clear cookies and block them in your browser settings. Strictly necessary cookies can't be
        disabled while you use the site.
      </p>

      <h2 className="font-serif text-2xl mt-8">Third-party cookies</h2>
      <p className="mt-2 text-ink-700">
        PayFast may set cookies during checkout to process payment. These are governed by PayFast's privacy notice.
      </p>
    </div>
  );
}
