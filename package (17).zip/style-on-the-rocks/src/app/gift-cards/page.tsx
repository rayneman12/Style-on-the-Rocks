import Link from 'next/link';

export const metadata = { title: 'Gift cards' };

export default function GiftCardsPage() {
  return (
    <div className="container-x py-12 md:py-16">
      <div className="grid gap-10 md:grid-cols-[3fr_2fr]">
        <div>
          <p className="eyebrow">Gift cards</p>
          <h1 className="h-section mt-2">A gift, their choice.</h1>
          <p className="mt-3 max-w-prose text-ink-600">
            Digital gift cards, delivered by email. Redeemable in-store and online, no expiry.
          </p>

          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {[
              { amount: 500, label: 'R 500' },
              { amount: 1000, label: 'R 1 000' },
              { amount: 2500, label: 'R 2 500' },
              { amount: 5000, label: 'R 5 000' },
            ].map((tier) => (
              <div key={tier.amount} className="border border-ink-200 bg-ivory-100 p-6 text-center">
                <p className="font-serif text-3xl">{tier.label}</p>
                <p className="mt-2 text-xs text-ink-500">Digital · delivered by email</p>
                <button className="btn-secondary mt-4 w-full" disabled>Add to bag</button>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-ink-500">
            Gift card purchase flow will be enabled alongside a real payment integration. For now, contact us to purchase.
          </p>
        </div>

        <aside className="h-fit border border-ink-200 bg-ivory-100 p-6 text-sm">
          <p className="eyebrow">Already have a code?</p>
          <p className="mt-2 text-ink-600">
            Enter it at checkout to redeem. Your gift card balance is applied to the order total.
          </p>
          <p className="eyebrow mt-6">Need help?</p>
          <p className="mt-2 text-ink-600">
            See <Link href="/faq" className="underline">FAQ</Link> or <Link href="/contact" className="underline">contact us</Link>.
          </p>
        </aside>
      </div>
    </div>
  );
}
