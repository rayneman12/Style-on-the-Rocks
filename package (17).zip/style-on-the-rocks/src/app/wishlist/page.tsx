'use client';
import { useEffect, useState } from 'react';
import { useWishlist } from '@/stores/wishlist';
import { ProductCard } from '@/components/product-card';

export default function WishlistPage() {
  const ids = useWishlist((s) => s.productIds);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!ids.length) {
      setProducts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetch(`/api/wishlist?ids=${encodeURIComponent(ids.join(','))}`)
      .then((r) => r.json())
      .then((d) => setProducts(Array.isArray(d) ? d : []))
      .catch(() => null)
      .finally(() => setLoading(false));
  }, [ids.join(',')]);

  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">Saved</p>
        <h1 className="h-section mt-2">Wishlist</h1>
      </header>
      {!ids.length ? (
        <div className="rounded border border-ink-200 bg-ivory-100 p-8 text-center">
          <p className="font-serif text-2xl">Nothing saved yet</p>
          <p className="mt-2 text-sm text-ink-500">Tap the heart icon on any product to save it here.</p>
          <a href="/shop" className="btn-secondary mt-4">Browse</a>
        </div>
      ) : loading ? (
        <p className="text-sm text-ink-500">Loading…</p>
      ) : products.length === 0 ? (
        <p className="text-sm text-ink-500">Saved items may have been removed — try browsing again.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}