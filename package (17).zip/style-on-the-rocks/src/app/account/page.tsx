import Link from 'next/link';
import { siteConfig } from '@config/site.config';

export const metadata = { title: 'Account' };

export default function AccountPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Account</p>
      <h1 className="h-section mt-2">Your account</h1>
      <p className="mt-3 text-ink-600">
        Account features are coming soon. For now, you can place orders as a guest and track them by email.
      </p>

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        <Link href="/wishlist" className="border border-ink-200 bg-ivory-100 p-6 hover:bg-ivory-200">
          <p className="font-serif text-xl">Wishlist</p>
          <p className="mt-2 text-sm text-ink-600">Pieces you've saved for later.</p>
        </Link>
        <Link href="/orders" className="border border-ink-200 bg-ivory-100 p-6 hover:bg-ivory-200">
          <p className="font-serif text-xl">Orders</p>
          <p className="mt-2 text-sm text-ink-600">Track and reorder past orders.</p>
        </Link>
      </div>

      <p className="mt-10 text-sm text-ink-500">
        Questions about an existing order? <a href="/contact" className="underline">Contact us</a> with your order number.
      </p>

      <p className="mt-2 text-sm text-ink-500">
        Boutique: {siteConfig.location.boutique}.
      </p>
    </div>
  );
}
