import { listProducts } from '@/lib/data';
import { ProductCard } from '@/components/product-card';

export const metadata = { title: 'New arrivals' };

export default async function NewArrivalsPage() {
  const products = await listProducts({ where: { isNew: true }, take: 60 });
  return (
    <div className="container-x py-10">
      <header className="mb-8">
        <p className="eyebrow">Edit</p>
        <h1 className="h-section mt-2">New arrivals</h1>
        <p className="mt-2 max-w-prose text-sm text-ink-500">Pieces that have just landed in the boutique. SAMPLE placeholders — replace with real stock via the admin panel.</p>
      </header>
      {products.length === 0 ? (
        <p className="text-sm text-ink-500">No new arrivals yet — check back soon.</p>
      ) : (
        <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3">
          {products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </div>
  );
}