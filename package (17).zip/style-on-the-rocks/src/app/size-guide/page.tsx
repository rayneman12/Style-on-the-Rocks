export const metadata = { title: 'Size guide' };

export default function SizeGuidePage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Help</p>
      <h1 className="h-section mt-2">Size guide</h1>
      <p className="mt-3 text-ink-600">
        Measurements in centimetres. If you're between sizes, we generally recommend sizing up.
        For tailoring, take your usual size.
      </p>

      <h2 className="font-serif text-2xl mt-10">Women — clothing</h2>
      <table className="mt-4 w-full text-sm">
        <thead className="text-ink-500">
          <tr>
            <th className="py-2 text-left">Size</th>
            <th className="py-2 text-right">Bust</th>
            <th className="py-2 text-right">Waist</th>
            <th className="py-2 text-right">Hips</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>XS</td><td className="text-right">82</td><td className="text-right">64</td><td className="text-right">88</td></tr>
          <tr><td>S</td><td className="text-right">86</td><td className="text-right">68</td><td className="text-right">92</td></tr>
          <tr><td>M</td><td className="text-right">90</td><td className="text-right">72</td><td className="text-right">96</td></tr>
          <tr><td>L</td><td className="text-right">94</td><td className="text-right">76</td><td className="text-right">100</td></tr>
          <tr><td>XL</td><td className="text-right">98</td><td className="text-right">80</td><td className="text-right">104</td></tr>
        </tbody>
      </table>

      <h2 className="font-serif text-2xl mt-8">Men — clothing</h2>
      <table className="mt-4 w-full text-sm">
        <thead className="text-ink-500">
          <tr>
            <th className="py-2 text-left">Size</th>
            <th className="py-2 text-right">Chest</th>
            <th className="py-2 text-right">Waist</th>
            <th className="py-2 text-right">Neck</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>S</td><td className="text-right">91</td><td className="text-right">78</td><td className="text-right">38</td></tr>
          <tr><td>M</td><td className="text-right">96</td><td className="text-right">83</td><td className="text-right">40</td></tr>
          <tr><td>L</td><td className="text-right">101</td><td className="text-right">88</td><td className="text-right">42</td></tr>
          <tr><td>XL</td><td className="text-right">106</td><td className="text-right">93</td><td className="text-right">44</td></tr>
        </tbody>
      </table>

      <h2 className="font-serif text-2xl mt-8">Shoes</h2>
      <p className="mt-2 text-ink-700">
        EU sizes. If you're a half-size, we recommend sizing up.
      </p>

      <h2 className="font-serif text-2xl mt-8">Need a hand?</h2>
      <p className="mt-2 text-ink-700">
        Email us your usual size and the piece you're looking at — we'll tell you whether to size up or down,
        or pop in for a fitting. See <a href="/book-a-stylist" className="underline">Book a stylist</a>.
      </p>
    </div>
  );
}
