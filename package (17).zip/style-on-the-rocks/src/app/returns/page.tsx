export const metadata = { title: 'Returns & refunds' };

export default function ReturnsPage() {
  return (
    <div className="container-x max-w-prose2 py-12 md:py-16">
      <p className="eyebrow">Help</p>
      <h1 className="h-section mt-2">Returns &amp; refunds</h1>

      <h2 className="font-serif text-2xl mt-10">Change of mind</h2>
      <p className="mt-2 text-ink-700">
        You can return full-price items within 14 days of receiving your order for an exchange or store credit.
        Items must be unworn, unwashed, with all tags attached.
      </p>

      <h2 className="font-serif text-2xl mt-8">Sale items</h2>
      <p className="mt-2 text-ink-700">
        Sale items are eligible for exchange or store credit only, within 14 days.
      </p>

      <h2 className="font-serif text-2xl mt-8">Faulty or incorrect items</h2>
      <p className="mt-2 text-ink-700">
        If something arrives damaged, faulty, or isn't what you ordered, we'll cover return shipping and
        refund in full. Email us within 7 days of receipt.
      </p>

      <h2 className="font-serif text-2xl mt-8">How to return</h2>
      <ol className="mt-2 list-decimal space-y-1 pl-5 text-ink-700">
        <li>Email <strong>returns@styleontherocks.example</strong> with your order number.</li>
        <li>We'll send a return form and a courier collection slot if applicable.</li>
        <li>Pack the item securely. Include the original receipt.</li>
        <li>Once we receive and check the item, we'll issue your exchange or refund within 3 business days.</li>
      </ol>

      <h2 className="font-serif text-2xl mt-8">Refunds</h2>
      <p className="mt-2 text-ink-700">
        Refunds go back to the original payment method. PayFast refunds typically clear within 5 business days;
        EFT refunds within 2 business days.
      </p>
    </div>
  );
}
