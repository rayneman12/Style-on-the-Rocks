import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/**/*.{ts,tsx,js,jsx,mdx}',
    './config/**/*.ts',
  ],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#FBF9F4',
          100: '#F5F0E6',
          200: '#EDE5D3',
        },
        sand: {
          100: '#EFE7D8',
          200: '#DCC9A6',
          300: '#C7AC78',
          400: '#A88A53',
        },
        ink: {
          DEFAULT: '#111111',
          900: '#0A0A0A',
          800: '#1A1A1A',
          700: '#2A2A2A',
          600: '#3F3F3F',
          500: '#5A5A5A',
          400: '#8A8A8A',
          300: '#B5B5B5',
          200: '#D6D6D6',
        },
        ocean: {
          DEFAULT: '#0F3D4C',
          400: '#1E5A6E',
          300: '#3D7A8C',
          200: '#7AA6B4',
          100: '#BFD7DD',
        },
        sea: {
          DEFAULT: '#9CC4C9',
          400: '#B6D6DA',
          300: '#CFE3E5',
        },
        brass: {
          DEFAULT: '#A8854A',
          400: '#C4A063',
          300: '#D9BC85',
        },
      },
      fontFamily: {
        serif: ['var(--font-serif)', 'Cormorant Garamond', 'Garamond', 'serif'],
        sans: ['var(--font-sans)', 'Inter', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        wider2: '0.14em',
        widest2: '0.24em',
      },
      maxWidth: {
        prose2: '64ch',
      },
      boxShadow: {
        soft: '0 1px 2px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06)',
      },
    },
  },
  plugins: [],
};

export default config;