/**
 * Verify site.config.ts — lists every config path that is still `null`.
 * Run with: npm run verify-config
 */
import { listMissingConfig } from '../config/site.config';

const missing = listMissingConfig();

console.log('Style on the Rocks — site.config verify');
console.log('========================================');
if (missing.length === 0) {
  console.log('All config values populated.');
  process.exit(0);
}
console.log(`Missing (${missing.length}):`);
for (const path of missing) {
  console.log(`  - ${path}`);
}
console.log('');
console.log(
  'These values must be supplied by the owner before going live. The storefront continues to render, but controls depending on these values (e.g. WhatsApp button, address on /visit-us, banking instructions on /checkout) are deliberately NOT rendered until the value is set.',
);
process.exit(0);