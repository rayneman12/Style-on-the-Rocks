#!/usr/bin/env bash
# bootstrap-db.sh — one-shot database bootstrap for Style on the Rocks (Phase 2).
#
# What this does:
#   1. Sanity-checks DATABASE_URL in .env (must be a postgres:// URL with sslmode=require).
#   2. Installs Node deps (pnpm preferred, npm fallback).
#   3. Generates the Prisma client.
#   4. Pushes the schema to the database (idempotent — safe to re-run).
#   5. Runs prisma/seed.ts to insert sample products / categories / admin user.
#
# When to run: once, on a machine that has egress to the database host (your laptop,
# the deploy host, or a CI runner with the right network policy). NOT from the build
# sandbox — the sandbox firewalls 5432 outbound.
#
# Usage:
#   ./scripts/bootstrap-db.sh           # reads DATABASE_URL from .env in the repo root
#   DATABASE_URL=postgres://... ./scripts/bootstrap-db.sh   # override

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

echo "[bootstrap-db] repo: $REPO_ROOT"

# 1. Load .env into the current shell so DATABASE_URL is visible to prisma.
if [ ! -f .env ]; then
  echo "[bootstrap-db] ERROR: .env not found at repo root." >&2
  exit 1
fi

# shellcheck disable=SC1091
set -a
. ./.env
set +a

if [ -z "${DATABASE_URL:-}" ]; then
  echo "[bootstrap-db] ERROR: DATABASE_URL is empty in .env." >&2
  exit 1
fi

case "$DATABASE_URL" in
  postgres://*|postgresql://*) ;;
  *)
    echo "[bootstrap-db] ERROR: DATABASE_URL must start with postgres:// or postgresql://" >&2
    exit 1
    ;;
esac

case "$DATABASE_URL" in
  *sslmode=require*) ;;
  *)
    echo "[bootstrap-db] WARNING: DATABASE_URL has no sslmode=require. Neon requires SSL; add ?sslmode=require." >&2
    ;;
esac

if [[ "$DATABASE_URL" == *"USER:PASSWORD@"* ]]; then
  echo "[bootstrap-db] ERROR: DATABASE_URL still contains the USER:PASSWORD@ placeholder. Replace it with the real creds from the Neon dashboard." >&2
  exit 1
fi

echo "[bootstrap-db] DATABASE_URL is set (host redacted)."

# 2. Install deps.
if command -v pnpm >/dev/null 2>&1; then
  echo "[bootstrap-db] installing deps with pnpm..."
  pnpm install --reporter=default
elif command -v npm >/dev/null 2>&1; then
  echo "[bootstrap-db] installing deps with npm..."
  npm install
else
  echo "[bootstrap-db] ERROR: neither pnpm nor npm is on PATH." >&2
  exit 1
fi

# 3. Generate Prisma client.
echo "[bootstrap-db] generating Prisma client..."
./node_modules/.bin/prisma generate

# 4. Push schema. Use the existing DATABASE_URL. db push is idempotent and doesn't
#    need a migration directory. If the schema already matches, this is a no-op.
echo "[bootstrap-db] pushing schema to database..."
./node_modules/.bin/prisma db push --accept-data-loss=false --skip-generate

# 5. Seed.
echo "[bootstrap-db] running seed (prisma/seed.ts)..."
./node_modules/.bin/tsx prisma/seed.ts

echo "[bootstrap-db] DONE. Sample admin: ${ADMIN_EMAIL:-admin@example.com} (password is in .env as ADMIN_PASSWORD — change it before going live)."
