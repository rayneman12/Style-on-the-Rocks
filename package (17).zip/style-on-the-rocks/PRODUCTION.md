# Style on the Rocks — Phase 2 status & production deployment

This is where the project stood at the end of the build session.

## What just changed (Phase 2 regression fixes)

1. **`src/components/session-provider.tsx`** created and wired into `src/app/layout.tsx`. Without this, `signIn()` from `/login` throws at runtime — NextAuth requires a `SessionProvider` in the React tree.
2. **`pgdata/` added to `.gitignore`**. The 47 MB local Postgres data dir is not portable across machines/versions; the source of truth is `prisma/schema.prisma` + `prisma/seed.ts` (which recreate the database anywhere). Exclude `pgdata/` from any future project zip.
3. **`output: 'export'` removed from `next.config.mjs`**. The production config is the one in the repo now — Node runtime only, no static export. If a static preview is genuinely needed for stakeholder review, build it from a separate branch / script and don't toggle this file back.
4. **`.env`'s `DATABASE_URL` reset to a placeholder** (`postgresql://USER:PASSWORD@HOST:5432/DBNAME?sslmode=require`). The previous value pointed at `localhost:55432`, which only exists inside the build sandbox. The host must supply a real `DATABASE_URL` (Neon or Supabase).

## Previous static preview

A static preview is still live at https://qve5tcon38kn.space.mcode.io as a design-reference snapshot. It does **not** reflect the latest regression fixes — it was built before `AuthSessionProvider` was wired in, so on that URL the login page would error at submit. That URL is now stale; ignore it. The Phase 2 deploy target is the Node host, not that static export.

## What's in Phase 2

- **`prisma/schema.prisma`** — schema converted from SQLite to **PostgreSQL** (provider = `postgresql`). One-way trip: SQLite can no longer be used once this line is `postgresql`. JSON fields use Prisma's native `Json` type.
- **`src/app/login/page.tsx`** — NextAuth credentials sign-in.
- **`src/app/api/auth/[...nextauth]/route.ts`** — NextAuth handler that re-exports the credentials provider from `src/lib/auth.ts`.
- **`src/components/session-provider.tsx`** — `AuthSessionProvider` client wrapper, mounted in `src/app/layout.tsx`.
- **`src/app/admin/page.tsx`** — read-only admin dashboard (recent orders, low-stock variants, pending stylist bookings, paid-revenue count). Page footer note: *"Order status changes, product editing, and confirming bookings still need to be wired up — this view is read-only for now."*
- **`src/app/api/bookings/route.ts`** — POST endpoint that takes the book-a-stylist form, validates with Zod, creates a `StylistBooking` row and emails the customer. (Add a notify-email-to-owner step here in Phase 3 if you want a copy going to the boutique as well.)
- **`src/app/book-a-stylist/page.tsx`** — client form that POSTs JSON to `/api/bookings`. Replaces the old form with no backend.
- **`prisma/seed.ts`** — creates categories, brands, 20 sample products, a promo code, sample gift cards, two journal posts, and a bootstrap admin user (email from `ADMIN_EMAIL`, password from `ADMIN_PASSWORD` in `.env`).

## Before the first real production deploy

These things still need to happen for true production. None of them are code changes — they're environment / credentials work the client (or this session) has to do.

### 1. Provision a hosted Postgres (Neon — this project)

The user picked **Neon** as the hosted Postgres. The project is already created:
- **Project ID:** `ep-lingering-field-b563efop`
- **Region:** `c-7.us-east-2` (US East / Ohio)
- **Database name:** `neondb`
- **Neon Auth is enabled** on the same project (separate feature — it issues JWTs and exposes `/.well-known/jwks.json`. It is **not** the database connection. The codebase currently uses NextAuth Credentials, so Neon Auth is dormant for now. See "Phase 3" below for the optional swap.)

**Connection status:** the real Neon pooler URL is already wired into `.env` (no `USER:PASSWORD@` placeholder left). Specifically:
```
postgresql://neondb_owner:npg_tuc39yHKmTjD@ep-lingering-field-b563efop-pooler.c-7.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require
```
This is the **pooler** endpoint (note `-pooler` in the hostname), which works fine for both `prisma db push` and the seed and normal app CRUD. Neon Auth is reachable but unused for now.

**One thing still has to happen — the database is empty.** The build sandbox where this code lives has all egress to Neon blocked (TCP 5432 and 443 both closed), so `prisma db push` and the seed have to run on a machine that can reach Neon. A one-shot script is included for exactly that:

```bash
cd style-on-the-rocks
./scripts/bootstrap-db.sh
```

What `bootstrap-db.sh` does:
1. Loads `.env` and refuses to run if `DATABASE_URL` is empty or still contains the `USER:PASSWORD@` placeholder.
2. Confirms `DATABASE_URL` starts with `postgres://`/`postgresql://` and has `sslmode=require`.
3. `pnpm install` (or `npm install` if pnpm isn't on the path).
4. `prisma generate`.
5. `prisma db push --accept-data-loss=false --skip-generate` (idempotent — safe to re-run).
6. `tsx prisma/seed.ts`.

The seed creates the bootstrap admin user at `ADMIN_EMAIL` with password `ADMIN_PASSWORD` from `.env`. The defaults are `admin@example.com` / `ChangeMe123!` — **change both before going live.**

**If `prisma db push` complains about `channel_binding=require`**, drop that one query parameter from `DATABASE_URL` and re-run. Neon's docs note that some Postgres drivers don't pass SCRAM channel binding correctly; Prisma's been fine with it historically but it's the most common cause of an obscure auth failure on this stack.

**If the pooler URL fails for `prisma db push` specifically** (rare, but the pooler can choke on DDL if it tries to use prepared statements), grab the **Direct connection** URL from the same Connection Details panel — same hostname without the `-pooler` infix, port 5432 — drop it into `.env` for the bootstrap step, then switch `.env` back to the pooler URL for the running app.

**Other hosts** still work identically — `postgresql://USER:PASSWORD@HOST:5432/DBNAME?sslmode=require`. If the client later switches away from Neon, the only change is the connection string. Schema is plain Postgres.

### 2. PayFast → real merchant account

`/api/payfast/notify` and the checkout redirect use the merchant id / key / passphrase. Right now the `.env` ships with PayFast's published **sandbox** values — that lets you test flows against the PayFast sandbox but no real money moves.

Client steps:
1. Sign the boutique up for a real PayFast merchant account → https://www.payfast.co.za/
2. In the PayFast dashboard, copy the live **Merchant ID**, **Merchant Key**, and set a **Passphrase**.
3. Replace `PAYFAST_MERCHANT_ID`, `PAYFAST_MERCHANT_KEY`, `PAYFAST_PASSPHRASE` in production env. Set `PAYFAST_SANDBOX=false`.
4. Configure the PayFast dashboard's **return / cancel / notify URLs** to point at `https://your-domain.tld/order/[id]`, `https://your-domain.tld/checkout`, `https://your-domain.tld/api/payfast/notify` respectively.

### 3. Deploy to a Node host

The repo's `next.config.mjs` no longer has `output: 'export'` — NextAuth + Prisma + `/api/*` require a real Node runtime.

Easiest path — **Vercel**:
1. `vercel link` then push to a Git provider, or import the repo via https://vercel.com/new
2. Add the env vars from `.env.example` (and `.env`) to the Vercel project: Postgres URL, `AUTH_SECRET` (generate with `openssl rand -base64 32`), `AUTH_URL`, `NEXT_PUBLIC_APP_URL`, PayFast live keys, Resend key, etc.
3. Don't change `next.config.mjs`. Just deploy.
4. Vercel runs `next build` then `next start`. The build will fail unless the `DATABASE_URL` env points at a reachable database — because `generateStaticParams` for `/shop/[category]`, `/brands/[brand]`, `/product/[slug]`, `/journal/[slug]` issue read queries at build time. Solution: either (a) point `DATABASE_URL` at the real Postgres for the build, then `prisma db push && tsx prisma/seed.ts` once before the build, or (b) temporarily set those pages to `force-dynamic` in this repo while you wire up the database.

Alternative hosts: **Railway**, **Render**, **Fly.io** — all work the same way (push the repo, set env, point at a managed Postgres, deploy).

## Local development

```bash
# install deps
pnpm install     # or npm install

# Postgres for local dev — easiest is Docker, or use a free Neon dev branch
# Set DATABASE_URL in .env to a working Postgres URL, then:
npm run db:push
npm run db:seed   # creates admin user from ADMIN_EMAIL / ADMIN_PASSWORD in .env
npm run dev       # http://localhost:3000
```

The seed creates a sample `admin@example.com` user with password `ChangeMe123!`. **Change both before deploying.**

## Phase 3 work that is still NOT wired up (and the admin dashboard says so openly)

These are obvious next steps if the client wants to actually run the shop:

- Admin status form (Order status changes) — currently the dashboard shows order state but doesn't have an update UI.
- Admin product edit — variants' stock is shown but not editable.
- Admin booking confirmation flow — `/api/bookings` records requests; confirming/cancelling/completing them is unimplemented.
- `/admin/emails` — there is no emails viewer yet; for now any sent emails go to console + Resend's dashboard.
- **Swap NextAuth Credentials for Neon Auth.** Neon Auth is already enabled on the project (`neonauth.c-7.us-east-2.aws.neon.tech` is reachable, JWKS endpoint returns a valid Ed25519 key). Swapping in would replace the email/password sign-in with hosted OAuth/magic-link, and the codebase would just need a new NextAuth provider that points at Neon's discovery URL + JWKS. The reason it isn't done now: it's a behaviour change for whoever logs in to `/admin` and the brief for Phase 2 was the credentials flow. Worth doing once the user actually has real admin users to onboard.
