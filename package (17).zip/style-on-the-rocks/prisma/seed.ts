/**
 * Seed — 20 SAMPLE products with neutral generated placeholders.
 * No real brand names. No fake reviews, testimonials, press.
 *
 * Run with: npm run db:seed (after npm run db:push).
 */
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { placeholderImage } from '../src/lib/placeholder-image';

const prisma = new PrismaClient();

const CATEGORIES = [
  { slug: 'women', name: 'Women', parent: null, position: 1 },
  { slug: 'men', name: 'Men', parent: null, position: 2 },
  { slug: 'dresses', name: 'Dresses', parent: 'women', position: 3 },
  { slug: 'tops', name: 'Tops', parent: 'women', position: 4 },
  { slug: 'trousers', name: 'Trousers', parent: 'women', position: 5 },
  { slug: 'jackets', name: 'Jackets', parent: 'women', position: 6 },
  { slug: 'shoes', name: 'Shoes', parent: 'women', position: 7 },
  { slug: 'bags', name: 'Bags', parent: 'accessories', position: 8 },
  { slug: 'accessories', name: 'Accessories', parent: null, position: 9 },
  { slug: 'fragrance', name: 'Fragrance', parent: null, position: 10 },
];

const BRANDS = [
  { slug: 'coastal-studio', name: 'Coastal Studio' },
  { slug: 'umhlanga-archive', name: 'Umhlanga Archive' },
  { slug: 'rocks-tailoring', name: 'Rocks Tailoring' },
  { slug: 'tidal-knitwear', name: 'Tidal Knitwear' },
];

type Sample = {
  slug: string;
  name: string;
  category: string;
  brand: string;
  price: number; // rands
  compareAt?: number;
  isNew?: boolean;
  isOnSale?: boolean;
  shortDescription: string;
  description: string;
  sizes: string[];
  variants: { color: string; sizes: { size: string; stock: number }[] }[];
  variant: 'sand' | 'ocean' | 'ivory' | 'brass';
};

const SAMPLES: Sample[] = [
  {
    slug: 'sample-linen-midi-dress',
    name: 'SAMPLE — Linen midi dress',
    category: 'dresses', brand: 'coastal-studio',
    price: 2895, compareAt: 3295, isOnSale: true,
    shortDescription: 'A relaxed linen midi in oat.',
    description: 'SAMPLE. A relaxed silhouette in lightweight European linen. Self-tie waist, side pockets.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Oat', sizes: [{ size: 'XS', stock: 4 }, { size: 'S', stock: 6 }, { size: 'M', stock: 2 }, { size: 'L', stock: 0 }] }],
    variant: 'sand',
  },
  {
    slug: 'sample-silk-slip-dress',
    name: 'SAMPLE — Silk slip dress',
    category: 'dresses', brand: 'umhlanga-archive',
    price: 4250, isNew: true,
    shortDescription: 'Bias-cut silk slip with cowl neckline.',
    description: 'SAMPLE. A bias-cut slip in heavyweight silk satin. French seams, adjustable straps.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Ink', sizes: [{ size: 'XS', stock: 2 }, { size: 'S', stock: 3 }, { size: 'M', stock: 1 }, { size: 'L', stock: 2 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-tailored-blazer',
    name: 'SAMPLE — Tailored blazer',
    category: 'jackets', brand: 'rocks-tailoring',
    price: 5495,
    shortDescription: 'Single-breasted, half-canvas construction.',
    description: 'SAMPLE. A half-canvas blazer cut from Italian tropical wool. Notch lapels, functional cuffs.',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    variants: [{ color: 'Charcoal', sizes: [{ size: 'XS', stock: 1 }, { size: 'S', stock: 4 }, { size: 'M', stock: 5 }, { size: 'L', stock: 3 }, { size: 'XL', stock: 2 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-merino-turtleneck',
    name: 'SAMPLE — Merino turtleneck',
    category: 'tops', brand: 'tidal-knitwear',
    price: 1850,
    shortDescription: 'Fine-gauge merino, ribbed roll neck.',
    description: 'SAMPLE. A fine-gauge merino turtleneck. Lightweight enough to layer, warm enough to wear alone.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Sea', sizes: [{ size: 'XS', stock: 3 }, { size: 'S', stock: 4 }, { size: 'M', stock: 4 }, { size: 'L', stock: 1 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-wide-leg-trouser',
    name: 'SAMPLE — Wide-leg trouser',
    category: 'trousers', brand: 'rocks-tailoring',
    price: 2950,
    shortDescription: 'High-rise, full-length wide leg.',
    description: 'SAMPLE. Cut from a wool-blend with a soft drape. Hidden side pockets, hook-and-bar closure.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Sand', sizes: [{ size: 'XS', stock: 2 }, { size: 'S', stock: 3 }, { size: 'M', stock: 3 }, { size: 'L', stock: 2 }] }],
    variant: 'sand',
  },
  {
    slug: 'sample-leather-tote',
    name: 'SAMPLE — Leather tote',
    category: 'bags', brand: 'coastal-studio',
    price: 6750,
    shortDescription: 'Full-grain leather, magnetic closure.',
    description: 'SAMPLE. Roomy enough for a 13" laptop. Full-grain Italian leather, cotton twill lining.',
    sizes: ['One'],
    variants: [{ color: 'Brass', sizes: [{ size: 'One', stock: 3 }] }],
    variant: 'brass',
  },
  {
    slug: 'sample-derby-shoe',
    name: 'SAMPLE — Derby shoe',
    category: 'shoes', brand: 'rocks-tailoring',
    price: 3850,
    shortDescription: 'Goodyear-welted Derby in box calf.',
    description: 'SAMPLE. A classic Derby on a leather sole, Goodyear-welted for resoleability.',
    sizes: ['7', '8', '9', '10', '11'],
    variants: [{ color: 'Black', sizes: [{ size: '7', stock: 1 }, { size: '8', stock: 2 }, { size: '9', stock: 3 }, { size: '10', stock: 2 }, { size: '11', stock: 1 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-cashmere-scarf',
    name: 'SAMPLE — Cashmere scarf',
    category: 'accessories', brand: 'umhlanga-archive',
    price: 1950, compareAt: 2350, isOnSale: true,
    shortDescription: 'Pure cashmere, hand-fringed.',
    description: 'SAMPLE. A lightweight cashmere scarf, generously sized. Hand-fringed edges.',
    sizes: ['One'],
    variants: [{ color: 'Oat', sizes: [{ size: 'One', stock: 6 }] }],
    variant: 'sand',
  },
  {
    slug: 'sample-eau-de-parfum',
    name: 'SAMPLE — Eau de parfum',
    category: 'fragrance', brand: 'coastal-studio',
    price: 1450,
    shortDescription: 'Bergamot, salt air, cedar, ambergris.',
    description: 'SAMPLE. A coastal fragrance with top notes of bergamot, a heart of salt air and white tea, and a base of cedar and ambergris. 50ml.',
    sizes: ['50ml'],
    variants: [{ color: '—', sizes: [{ size: '50ml', stock: 12 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-oxford-shirt',
    name: 'SAMPLE — Oxford shirt',
    category: 'tops', brand: 'rocks-tailoring',
    price: 1650,
    shortDescription: 'Pinpoint oxford with a cutaway collar.',
    description: 'SAMPLE. A pinpoint oxford button-down, tailored fit, mother-of-pearl buttons.',
    sizes: ['S', 'M', 'L', 'XL'],
    variants: [{ color: 'White', sizes: [{ size: 'S', stock: 4 }, { size: 'M', stock: 5 }, { size: 'L', stock: 4 }, { size: 'XL', stock: 2 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-denim-jacket',
    name: 'SAMPLE — Selvedge denim jacket',
    category: 'jackets', brand: 'coastal-studio',
    price: 3250,
    shortDescription: 'Japanese 14oz selvedge denim.',
    description: 'SAMPLE. Type II jacket in Japanese selvedge. Will fade with wear. Sanforized.',
    sizes: ['S', 'M', 'L'],
    variants: [{ color: 'Indigo', sizes: [{ size: 'S', stock: 2 }, { size: 'M', stock: 3 }, { size: 'L', stock: 1 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-knit-polo',
    name: 'SAMPLE — Knit polo',
    category: 'tops', brand: 'tidal-knitwear',
    price: 1450,
    shortDescription: 'Long-staple cotton knit polo.',
    description: 'SAMPLE. A knit polo in long-staple Egyptian cotton. Mother-of-pearl buttons, ribbed collar.',
    sizes: ['S', 'M', 'L', 'XL'],
    variants: [{ color: 'Sea', sizes: [{ size: 'S', stock: 3 }, { size: 'M', stock: 4 }, { size: 'L', stock: 3 }, { size: 'XL', stock: 1 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-pleated-skirt',
    name: 'SAMPLE — Pleated skirt',
    category: 'dresses', brand: 'umhlanga-archive',
    price: 2350, isNew: true,
    shortDescription: 'Knife-pleated, sits at the waist.',
    description: 'SAMPLE. A floor-length knife-pleated skirt in a fluid satin-back crepe.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Ink', sizes: [{ size: 'XS', stock: 2 }, { size: 'S', stock: 3 }, { size: 'M', stock: 2 }, { size: 'L', stock: 1 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-canvas-sneaker',
    name: 'SAMPLE — Canvas sneaker',
    category: 'shoes', brand: 'coastal-studio',
    price: 1450,
    shortDescription: 'Hand-stitched canvas low-top.',
    description: 'SAMPLE. A vulcanised rubber-sole sneaker in heavyweight cotton canvas.',
    sizes: ['6', '7', '8', '9', '10'],
    variants: [{ color: 'Oat', sizes: [{ size: '6', stock: 1 }, { size: '7', stock: 3 }, { size: '8', stock: 3 }, { size: '9', stock: 2 }, { size: '10', stock: 1 }] }],
    variant: 'sand',
  },
  {
    slug: 'sample-leather-belt',
    name: 'SAMPLE — Leather belt',
    category: 'accessories', brand: 'rocks-tailoring',
    price: 1250,
    shortDescription: 'Bridle leather with brass buckle.',
    description: 'SAMPLE. A 30mm bridle leather belt with a solid brass roller buckle.',
    sizes: ['S', 'M', 'L'],
    variants: [{ color: 'Brass', sizes: [{ size: 'S', stock: 4 }, { size: 'M', stock: 5 }, { size: 'L', stock: 3 }] }],
    variant: 'brass',
  },
  {
    slug: 'sample-tailored-trouser',
    name: 'SAMPLE — Tailored trouser',
    category: 'trousers', brand: 'rocks-tailoring',
    price: 2650,
    shortDescription: 'Pleated, tapered ankle.',
    description: 'SAMPLE. A single-pleat trouser in Italian wool. Side adjusters, button fly.',
    sizes: ['28', '30', '32', '34', '36'],
    variants: [{ color: 'Charcoal', sizes: [{ size: '28', stock: 1 }, { size: '30', stock: 3 }, { size: '32', stock: 4 }, { size: '34', stock: 2 }, { size: '36', stock: 1 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-clutch-bag',
    name: 'SAMPLE — Envelope clutch',
    category: 'bags', brand: 'umhlanga-archive',
    price: 2350, isNew: true,
    shortDescription: 'Foldover clutch in nappa.',
    description: 'SAMPLE. A soft envelope clutch in Italian nappa with a magnetic snap.',
    sizes: ['One'],
    variants: [{ color: 'Ink', sizes: [{ size: 'One', stock: 4 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-silk-scarf',
    name: 'SAMPLE — Silk scarf',
    category: 'accessories', brand: 'coastal-studio',
    price: 1450,
    shortDescription: '90cm silk twill, hand-rolled hem.',
    description: 'SAMPLE. A 90cm silk twill square with hand-rolled edges.',
    sizes: ['One'],
    variants: [{ color: 'Sea', sizes: [{ size: 'One', stock: 5 }] }],
    variant: 'ocean',
  },
  {
    slug: 'sample-roll-neck-dress',
    name: 'SAMPLE — Roll-neck dress',
    category: 'dresses', brand: 'tidal-knitwear',
    price: 3450,
    shortDescription: 'Fine merino knit dress.',
    description: 'SAMPLE. A fine merino dress with a roll neck, fitted waist and A-line skirt.',
    sizes: ['XS', 'S', 'M', 'L'],
    variants: [{ color: 'Charcoal', sizes: [{ size: 'XS', stock: 1 }, { size: 'S', stock: 2 }, { size: 'M', stock: 2 }, { size: 'L', stock: 1 }] }],
    variant: 'ivory',
  },
  {
    slug: 'sample-room-fragrance',
    name: 'SAMPLE — Room fragrance',
    category: 'fragrance', brand: 'coastal-studio',
    price: 950,
    shortDescription: 'Salt air, fig leaf, cedar.',
    description: 'SAMPLE. A reed-diffuser room fragrance, hand-poured in small batches. 200ml.',
    sizes: ['200ml'],
    variants: [{ color: '—', sizes: [{ size: '200ml', stock: 10 }] }],
    variant: 'sand',
  },
];

async function main() {
  console.log('Resetting...');
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.cartItem.deleteMany();
  await prisma.wishlistItem.deleteMany();
  await prisma.productImage.deleteMany();
  await prisma.productVariant.deleteMany();
  await prisma.product.deleteMany();
  await prisma.category.deleteMany();
  await prisma.brand.deleteMany();
  await prisma.journalPost.deleteMany();
  await prisma.promoCode.deleteMany();
  await prisma.giftCard.deleteMany();
  await prisma.stylistBooking.deleteMany();
  await prisma.newsletterSubscriber.deleteMany();
  await prisma.review.deleteMany();
  await prisma.user.deleteMany();

  console.log('Inserting categories...');
  for (const c of CATEGORIES) {
    await prisma.category.create({ data: c });
  }
  console.log('Inserting brands...');
  for (const b of BRANDS) {
    await prisma.brand.create({ data: { ...b, bio: `SAMPLE — placeholder brand. ${b.name} is shown only to demonstrate the catalogue structure.` } });
  }

  console.log('Inserting sample products...');
  let i = 0;
  for (const s of SAMPLES) {
    i++;
    const cat = await prisma.category.findUnique({ where: { slug: s.category } });
    const br = await prisma.brand.findUnique({ where: { slug: s.brand } });
    if (!cat || !br) throw new Error(`Missing ${s.category} or ${s.brand}`);
    const img1 = placeholderImage({ label: s.name, seed: i, variant: s.variant });
    const img2 = placeholderImage({ label: s.name, seed: i + 100, variant: 'ivory' });
    const p = await prisma.product.create({
      data: {
        slug: s.slug,
        name: s.name,
        shortDescription: s.shortDescription,
        description: s.description,
        priceCents: s.price * 100,
        compareAtCents: s.compareAt ? s.compareAt * 100 : null,
        sku: `SAMPLE-${i.toString().padStart(3, '0')}`,
        status: 'ACTIVE',
        isNew: s.isNew ?? false,
        isOnSale: s.isOnSale ?? false,
        tagsCsv: ['sample', s.category, s.brand].join(','),
        brandId: br.id,
        categoryId: cat.id,
        images: { create: [{ url: img1, alt: s.name, position: 0 }, { url: img2, alt: s.name + ' — alternate', position: 1 }] },
      },
    });
    for (const v of s.variants) {
      for (const sz of v.sizes) {
        await prisma.productVariant.create({
          data: {
            productId: p.id,
            size: sz.size,
            color: v.color,
            stock: sz.stock,
          },
        });
      }
    }
  }

  console.log('Inserting sample promo code...');
  await prisma.promoCode.create({
    data: {
      code: 'WELCOME10',
      type: 'PERCENT',
      value: 10,
      minSubtotalCents: 0,
      active: true,
      usageLimit: 1000,
    },
  });

  console.log('Inserting sample gift cards...');
  await prisma.giftCard.create({
    data: { code: 'DEMO-GC-1000', initialCents: 100000, balanceCents: 100000, recipientName: 'Demo card' },
  });

  console.log('Inserting sample journal posts...');
  await prisma.journalPost.create({
    data: {
      slug: 'coastal-summer-edit',
      title: 'The coastal summer edit',
      excerpt: 'SAMPLE — A short editorial note on dressing for warm coast days.',
      body: '## Coastal summer\n\nThis is a SAMPLE journal post. Replace via the admin panel with real editorial.\n\n- Lightweight linens\n- Soft tailoring\n- Sand-friendly palettes',
      published: true,
      publishedAt: new Date(),
      coverImage: placeholderImage({ label: 'Coastal summer', seed: 7, variant: 'sand' }),
    },
  });
  await prisma.journalPost.create({
    data: {
      slug: 'how-we-choose-stock',
      title: 'How we choose what we stock',
      excerpt: 'SAMPLE — A note on our buying philosophy.',
      body: '## Buying notes\n\nSAMPLE content. Replace via admin.',
      published: true,
      publishedAt: new Date(Date.now() - 86400000 * 7),
      coverImage: placeholderImage({ label: 'Buying notes', seed: 8, variant: 'ocean' }),
    },
  });

  console.log('Creating admin user from .env...');
  const email = (process.env.ADMIN_EMAIL ?? 'admin@example.com').toLowerCase();
  const password = process.env.ADMIN_PASSWORD ?? 'ChangeMe123!';
  await prisma.user.create({
    data: {
      email,
      name: 'Admin',
      role: 'ADMIN',
      passwordHash: await bcrypt.hash(password, 10),
    },
  });
  console.log(`Admin user: ${email} / ${password}`);

  console.log('Done.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());