/**
 * Style on the Rocks — site configuration
 *
 * Every value the owner has NOT yet supplied is set to `null`.
 * `npm run verify-config` lists what is still missing.
 * No fake address, hours, phone, WhatsApp, email or banking details are stored here.
 */

export type SiteConfig = {
  brand: {
    name: string;
    legalName: string | null;
    tagline: string;
    description: string;
    established: number | null;
  };
  contact: {
    email: string | null;
    phone: string | null;
    whatsapp: string | null; // digits only, no "+", e.g. "27821234567"
    instagram: string;
    facebook: string;
    tiktok: string;
  };
  location: {
    boutique: string; // human label e.g. "Umhlanga Rocks boutique"
    addressLine1: string | null;
    addressLine2: string | null;
    suburb: string | null;
    city: string | null;
    province: string | null;
    postcode: string | null;
    country: string;
    // Approximate coords for the map embed until a real address is supplied.
    mapLat: number;
    mapLng: number;
    mapZoom: number;
  };
  hours: {
    // Each entry: ["Mon", "09:00", "17:00"]. null = closed.
    weekly: Array<[string, string | null, string | null]>;
    publicNote: string | null;
  };
  legal: {
    companyRegNumber: string | null;
    vatNumber: string | null;
  };
  commerce: {
    currency: 'ZAR';
    vatRate: 0.15;
    freeDeliveryThresholdZAR: number;
    // Banking details for EFT — null until owner supplies.
    bank: {
      accountName: string | null;
      bankName: string | null;
      accountNumber: string | null;
      branchCode: string | null;
      referenceNote: string;
    } | null;
  };
  payments: {
    payfast: {
      sandbox: boolean;
      merchantId: string | null;
      merchantKey: string | null;
      passphrase: string | null;
    };
  };
  email: {
    resendApiKey: string | null;
    fromAddress: string;
    fromName: string;
  };
  features: {
    enablePayfast: boolean;
    enableEft: boolean;
    enableWhatsapp: boolean; // derived from contact.whatsapp
    enableCourierLiveRates: boolean;
  };
  socialProof: {
    // No fake reviews / testimonials / press logos — explicitly null.
    reviews: null;
    testimonials: null;
    press: null;
  };
};

export const siteConfig: SiteConfig = {
  brand: {
    name: 'Style on the Rocks',
    legalName: null,
    tagline: 'Coastal luxury, curated for the coast.',
    description:
      'A luxury fashion boutique for women and men in Umhlanga Rocks, KwaZulu-Natal.',
    established: null,
  },
  contact: {
    email: null,
    phone: null,
    whatsapp: null,
    instagram: 'https://www.instagram.com/style_on_the_rocks_sa/',
    facebook: 'https://www.facebook.com/p/Style-On-The-Rocks-100063764104383/',
    tiktok: 'https://www.tiktok.com/@style.on.the.rocks',
  },
  location: {
    boutique: 'Umhlanga Rocks boutique',
    addressLine1: null,
    addressLine2: null,
    suburb: null,
    city: 'Umhlanga Rocks',
    province: 'KwaZulu-Natal',
    postcode: null,
    country: 'South Africa',
    // Approximate Umhlanga Rocks — used only until a real address is supplied.
    mapLat: -29.7286,
    mapLng: 31.0656,
    mapZoom: 14,
  },
  hours: {
    weekly: [
      ['Mon', null, null],
      ['Tue', null, null],
      ['Wed', null, null],
      ['Thu', null, null],
      ['Fri', null, null],
      ['Sat', null, null],
      ['Sun', null, null],
    ],
    publicNote: null,
  },
  legal: {
    companyRegNumber: null,
    vatNumber: null,
  },
  commerce: {
    currency: 'ZAR',
    vatRate: 0.15,
    freeDeliveryThresholdZAR: 1500,
    bank: null,
  },
  payments: {
    payfast: {
      sandbox: true,
      merchantId: process.env.PAYFAST_MERCHANT_ID ?? '10000100', // PayFast published sandbox merchant
      merchantKey: process.env.PAYFAST_MERCHANT_KEY ?? '46f0cd694581a4e6a55bdb3f82c40f66', // PayFast published sandbox key
      passphrase: process.env.PAYFAST_PASSPHRASE ?? 'jt7XIE53wEQIG', // PayFast published sandbox passphrase
    },
  },
  email: {
    resendApiKey: process.env.RESEND_API_KEY ?? null,
    fromAddress: 'orders@styleontherocks.example',
    fromName: 'Style on the Rocks',
  },
  features: {
    enablePayfast: true,
    enableEft: true,
    enableWhatsapp: false, // becomes true when contact.whatsapp is set
    enableCourierLiveRates: false,
  },
  socialProof: {
    reviews: null,
    testimonials: null,
    press: null,
  },
};

/** Returns list of config paths that are still null — used by verify-config. */
export function listMissingConfig(): string[] {
  const missing: string[] = [];
  const walk = (obj: any, prefix: string) => {
    for (const [k, v] of Object.entries(obj)) {
      const path = `${prefix}.${k}`;
      if (v === null) {
        missing.push(path);
      } else if (typeof v === 'object' && !Array.isArray(v) && v instanceof Object) {
        walk(v, path);
      }
    }
  };
  walk(siteConfig, 'siteConfig');
  return missing;
}

/** Derive whether WhatsApp links should render. */
export function whatsappEnabled(): boolean {
  return Boolean(siteConfig.contact.whatsapp);
}